<?php

namespace App\Models\buttons;

use App\Models\buttons\extend\AbstractButtonsViber;

class ButtonsViber extends AbstractButtonsViber {

//    public function main() {
//        return [];
//    }
}
