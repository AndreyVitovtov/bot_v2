<?php


namespace App\Services\Implement;


use App\Services\Contracts\BotService;

class BotServiceImpl implements BotService {

}
