<?php


namespace App\Services\Contracts;


interface BotService {

}
