<?php

namespace App\Http\Controllers;

class Test extends Controller {
    public function index() {

    }
}
