

<?php $__env->startSection("title"); ?>
    <?php echo app('translator')->get('pages.moderators_permissions'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("h3"); ?>
    <h3><?php echo app('translator')->get('pages.moderators_permissions'); ?></h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("main"); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/permissions.css')); ?>">

    <form action="<?php echo e(route('moderators-save-permissions')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="overflow-X-auto">
            <table>
                <tr>
                    <td><?php echo app('translator')->get('pages.moderators'); ?></td>
                    <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td><?php echo e($permission->name); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
                <?php $__currentLoopData = $moderators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $moderator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($moderator->name); ?></td>
                        <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <td class="tac">
                                <input type="checkbox"
                                       name="<?php echo e($moderator->id); ?>_<?php echo e($permission->id); ?>"
                                       value="<?php echo e($permission->id); ?>"
                                <?php if($moderator->hasPermissionById($permission->id)): ?>
                                    checked
                                <?php endif; ?>>
                            </td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
        <br>
        <input type="submit" value="<?php echo app('translator')->get('pages.moderators_permissions_save'); ?>" class="button">
    </form>
<?php $__env->stopSection(); ?>



<?php echo $__env->make("admin.template", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\bot_laravel_8\resources\views/admin/moderators/permissions.blade.php ENDPATH**/ ?>