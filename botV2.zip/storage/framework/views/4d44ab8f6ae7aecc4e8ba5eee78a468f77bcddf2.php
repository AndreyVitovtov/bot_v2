

<?php $__env->startSection("title"); ?>
    Яндекс Деньги
<?php $__env->stopSection(); ?>

<?php $__env->startSection("h3"); ?>
    <h3>Яндекс Деньги</h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("main"); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/pay.css')); ?>">

    <div class="payment">
        <div>
            <form action="<?php echo route('yandex-save'); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div>
                    <label for="secret">Secret key:</label>
                    <input type="text" name="secret" id="secret" value="<?php echo e(isset($secret) ? $secret : ""); ?>">
                </div>
                <div>
                    <label for="wallet">Номер кошелька:</label>
                    <input type="text" name="wallet" id="wallet" value="<?php echo e(isset($wallet) ? $wallet : ""); ?>">
                </div>
                <br>
                <div>
                    <input type="submit" value="Сохранить" class="button">
                </div>
            </form>
        </div>
        <br>
        <pre>Подключить http уведомления:</pre>
        <pre><a href="https://money.yandex.ru/myservices/online.xml" target="_blank">https://money.yandex.ru/myservices/online.xml</a></pre>
        <pre>Адрес: <?php echo e(url('/payment/yandex/handler')); ?></pre>
        <pre>Secret key: Кнопка "Показать секрет"</pre>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("developer.template", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\botV2\resources\views/developer/payment/yandex-index.blade.php ENDPATH**/ ?>