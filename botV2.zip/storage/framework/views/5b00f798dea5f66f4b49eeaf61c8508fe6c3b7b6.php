<?php $__env->startSection("title"); ?>
    <?php echo app('translator')->get('pages.contacts'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("h3"); ?>
    <h3><?php echo app('translator')->get('pages.contacts'); ?></h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("main"); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/contacts.css')); ?>">

    <div class="contacts">
        <div>
            <div class="overflow-X-auto">
                <table>
                    <tr>
                        <td>
                            <input type="checkbox" name="check_all" id="check_all">
                        </td>
                        <td>
                            №
                        </td>
                        <td>
                            <?php echo app('translator')->get('pages.contacts_user'); ?>
                        </td>
                        <td>
                            <?php echo app('translator')->get('pages.contacts_message'); ?>
                        </td>
                        <td>
                            <?php echo app('translator')->get('pages.contacts_date'); ?>
                        </td>
                        <td>
                            <?php echo app('translator')->get('pages.actions'); ?>
                        </td>
                    </tr>
                    <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <input type="checkbox" name="offer[]" value="<?php echo e($contact->id); ?>" class="checkbox">
                            </td>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td>
                                <a href="/admin/users/profile/<?php echo e($contact->users->id); ?>"><?php echo e($contact->users->username); ?></a>
                            </td>
                            <td>
                                <?php echo e($contact->text); ?>

                            </td>
                            <td>
                                <?php echo e($contact->date); ?> <?php echo e($contact->time); ?>

                            </td>
                            <td class="actions">
                                <div>
                                    <form action="/admin/contacts/answer" method="POST" id="form-answer-<?php echo e($contact->id); ?>">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="id" value="<?php echo e($contact->id); ?>">
                                        <button form="form-answer-<?php echo e($contact->id); ?>">
                                            <i class='icon-comment-6'></i>
                                        </button>
                                    </form>

                                    <form action="<?php echo e(route('contacts-delete')); ?>" method="POST" id="form-delete-<?php echo e($contact->id); ?>">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="id" value="<?php echo e($contact->id); ?>">
                                        <button form="form-delete-<?php echo e($contact->id); ?>">
                                            <i class='icon-trash-empty'></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
            <?php echo e($contacts->links()); ?>

            <br>
            <div>
                <form action="<?php echo e(route('contacts-delete-check')); ?>" method="POST" id="form-delete-check">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="data" class="data-form-delete-check">
                    <input type="hidden" name="type" value="<?php echo e($type); ?>">
                    <button type="submit" id="form-delete-check-submit" class="button"><?php echo app('translator')->get('pages.delete_checked'); ?></button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("admin.template", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\botV2\resources\views/admin/contacts/contacts-list.blade.php ENDPATH**/ ?>