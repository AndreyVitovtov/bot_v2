<script src="<?php echo e(asset('https://www.gstatic.com/charts/loader.js')); ?>"></script>
<script src="<?php echo e(asset('js/admin-panel/charts/Chart.js')); ?>"></script>
<?php /**PATH D:\OSPanel\domains\botV2\resources\views/components/chart.blade.php ENDPATH**/ ?>