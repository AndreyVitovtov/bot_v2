<?php $__env->startSection("title"); ?>
    <?php echo app('translator')->get('pages.add_menu_bot'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("h3"); ?>
    <h3><?php echo app('translator')->get('pages.add_menu_bot'); ?></h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("main"); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/menu.css')); ?>">
    <script src="<?php echo e(asset('js/developer-panel/add-menu.js')); ?>"></script>
    <label for="menu-name"><?php echo app('translator')->get('pages.name_menu'); ?></label>
    <input type="text" name="menu-name" id="menu-name">
    <br>
    <br>
    <div class="flex">
        <div class="menu-bot">
            <div>
                <div class="str">
                    <div class="buttons buttons1"></div>
                </div>
                <div class="add add-right" data-class="buttons1">
                    <i class="icon-right-outline"></i>
                </div>
            </div>
            <div class="str0">
            </div>
            <div>
                <div class="str" id="str">
                </div>
                <div class="add add_bottom" id="add-bottom">
                    <i class="icon-down-outline"></i>
                </div>
            </div>
        </div>
        <div class="block-buttons-bot">
        </div>
    </div>
    <br>
    <br>
    <div class="button save-menu"><?php echo app('translator')->get('pages.save'); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("developer.template", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\botV2\resources\views/developer/menu/add.blade.php ENDPATH**/ ?>