<?php $__env->startSection("title"); ?>
    <?php echo app('translator')->get('pages.add_text_pages'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("h3"); ?>
    <h3><?php echo app('translator')->get('pages.add_text_pages'); ?></h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("main"); ?>
    <form action="<?php echo e(route('lang-pages-add-save')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div>
            <label for="text"><?php echo app('translator')->get('pages.text'); ?></label>
            <input type="text" name="text" id="text">
        </div>
        <div>
            <label for="key"><?php echo app('translator')->get('pages.key'); ?></label>
            <input type="text" name="key" id="key">
        </div>
        <br>
        <div>
            <input type="submit" value="<?php echo app('translator')->get('pages.add'); ?>" class="button">
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("developer.template", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\botV2\resources\views/developer/lang/pages-add.blade.php ENDPATH**/ ?>