

<?php $__env->startSection("title"); ?>
    <?php echo app('translator')->get('pages.languages_list'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("h3"); ?>
    <h3><?php echo app('translator')->get('pages.languages_list'); ?></h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("main"); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/languages.css')); ?>">
    <div class="overflow-X-auto">
        <table>
            <tr>
                <td>
                    №
                </td>
                <td>
                    <?php echo app('translator')->get('pages.languages_name'); ?>
                </td>
                <td>
                    <?php echo app('translator')->get('pages.languages_code'); ?>
                </td>
                <td>
                    <?php echo app('translator')->get('pages.languages_emoji'); ?>
                </td>
                <td>
                    <?php echo app('translator')->get('pages.languages_delete'); ?>
                </td>
            </tr>
            <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <?php echo e($loop->iteration); ?>

                    </td>
                    <td>
                        <?php echo e($lang->name); ?>

                    </td>
                    <td>
                        <?php echo e($lang->code); ?>

                    </td>
                    <td>
                        <?php echo e(base64_decode($lang->emoji)); ?>

                    </td>
                    <td class="actions">
                        <div>
                            <form action="<?php echo e(route('languages-delete')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="id" value="<?php echo e($lang->id); ?>">
                                <button>
                                    <i class='icon-trash-empty'></i>
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("admin.template", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\bot_laravel_8\resources\views/admin/languages/list.blade.php ENDPATH**/ ?>