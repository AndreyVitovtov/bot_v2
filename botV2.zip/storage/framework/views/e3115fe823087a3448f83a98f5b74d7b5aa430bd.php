<?php $__env->startSection("title"); ?>
    <?php echo app('translator')->get('pages.settings_admin'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("h3"); ?>
    <h3><?php echo app('translator')->get('pages.settings_admin'); ?></h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("main"); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/settings.css')); ?>">
    <div class="settings">
        <form action="/admin/settings/save" method="POST">
            <?php echo csrf_field(); ?>
            <div>
                <label for="name"><?php echo app('translator')->get('pages.name'); ?></label>
                <input type="text" name="name" id="name" value="<?php echo e(Auth::user()->name); ?>">
            </div>
            <div>
                <label for="login"><?php echo app('translator')->get('pages.login'); ?></label>
                <input type="text" name="login" id="login" value="<?php echo e(Auth::user()->login); ?>">
            </div>
            <div>
                <label for="password"><?php echo app('translator')->get('pages.new_password'); ?></label>
                <input type="password" name="password" id="password">
            </div>
            <div>
                <label for="confirm_password"><?php echo app('translator')->get('pages.confirm_password'); ?></label>
                <input type="password" name="confirm_password" id="confirm_password">
            </div>
            <div>
                <label for="name_bot"><?php echo app('translator')->get('pages.name_bot'); ?></label>
                <input type="text" name="name_bot" value="<?php echo app('translator')->get('pages.bot_name'); ?>" id="name_bot">
            </div>
            <br>
            <div>
                <button class="button"><?php echo app('translator')->get('pages.save'); ?></button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("admin.template", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\botV2\resources\views/admin/settings/settings-admin.blade.php ENDPATH**/ ?>