<form action="<?php echo e(route('send-request')); ?>" method="POST" id="send-request">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="method" value="<?php echo e($method); ?>">
    <input type="hidden" name="messenger" value="<?php echo e($messenger); ?>">
    <input type="hidden" name="url" value="<?php echo e($url); ?>">
    <input type="hidden" name="data" value="<?php echo e($data); ?>">
    <input type="hidden" name="response" value="<?php echo e($response); ?>">
</form>

<script>
    window.onload = function() {
        let form = document.getElementById('send-request');
        form.submit();
    }
</script>
<?php /**PATH D:\OSPanel\domains\botV2\resources\views/developer/request/redirect-send.blade.php ENDPATH**/ ?>