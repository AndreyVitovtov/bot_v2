<?php $__env->startComponent('menu.menu-item', [
   'name' => 'developer_admin_panel',
   'icon' => 'icon-user-3',
   'menu' => 'admin',
   'url' => '/admin'
]); ?><?php if (isset($__componentOriginal6d24f37cb7e6d98d46a220195dece646fa7436ce)): ?>
<?php $component = $__componentOriginal6d24f37cb7e6d98d46a220195dece646fa7436ce; ?>
<?php unset($__componentOriginal6d24f37cb7e6d98d46a220195dece646fa7436ce); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>






<?php $__env->startComponent('menu.menu-item', [
    'name' => 'request',
    'icon' => 'icon-code-2',
    'menu' => 'request',
    'url' => '/developer/request'
]); ?><?php if (isset($__componentOriginal6d24f37cb7e6d98d46a220195dece646fa7436ce)): ?>
<?php $component = $__componentOriginal6d24f37cb7e6d98d46a220195dece646fa7436ce; ?>
<?php unset($__componentOriginal6d24f37cb7e6d98d46a220195dece646fa7436ce); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->startComponent('menu.menu-item', [
    'name' => 'send_request',
    'icon' => 'icon-rocket',
    'menu' => 'send_request',
    'url' => '/developer/request/send'
]); ?><?php if (isset($__componentOriginal6d24f37cb7e6d98d46a220195dece646fa7436ce)): ?>
<?php $component = $__componentOriginal6d24f37cb7e6d98d46a220195dece646fa7436ce; ?>
<?php unset($__componentOriginal6d24f37cb7e6d98d46a220195dece646fa7436ce); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->startComponent('menu.menu-item', [
    'name' => 'developer_answers',
    'icon' => 'icon-help-1',
    'menu' => 'answers',
    'url' => '/developer/answers'
]); ?><?php if (isset($__componentOriginal6d24f37cb7e6d98d46a220195dece646fa7436ce)): ?>
<?php $component = $__componentOriginal6d24f37cb7e6d98d46a220195dece646fa7436ce; ?>
<?php unset($__componentOriginal6d24f37cb7e6d98d46a220195dece646fa7436ce); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->startComponent('menu.menu-rolled', [
    'nameItem' => 'menumenu',
    'icon' => 'icon-th',
    'name' => 'menu',
    'items' => [
        [
            'name' => 'list',
            'menu' => 'menu-list',
            'url' => '/developer/menu/list'
        ], [
           'name' => 'add',
           'menu' => 'menu-add',
           'url' => '/developer/menu/add'
        ]
    ]
]); ?><?php if (isset($__componentOriginal629642e31854f2f3c320339cf9ca8b7a9b63fe21)): ?>
<?php $component = $__componentOriginal629642e31854f2f3c320339cf9ca8b7a9b63fe21; ?>
<?php unset($__componentOriginal629642e31854f2f3c320339cf9ca8b7a9b63fe21); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
























<?php $__env->startComponent('menu.menu-rolled', [
    'nameItem' => 'developer_admin_menu',
    'icon' => 'icon-menu-1',
    'name' => 'developer_admin_menu',
    'items' => [
        [
            'name' => 'list',
            'menu' => 'developeradminmenulist',
            'url' => '/developer/menu/admin/list'
        ], [
            'name' => 'add',
            'menu' => 'developeradminmenuadd',
            'url' => '/developer/menu/admin/add'
        ]
    ]
]); ?><?php if (isset($__componentOriginal629642e31854f2f3c320339cf9ca8b7a9b63fe21)): ?>
<?php $component = $__componentOriginal629642e31854f2f3c320339cf9ca8b7a9b63fe21; ?>
<?php unset($__componentOriginal629642e31854f2f3c320339cf9ca8b7a9b63fe21); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

<?php $__env->startComponent('menu.menu-rolled', [
    'nameItem' => 'developer_lang',
    'icon' => 'icon-language-1',
    'name' => 'developer_lang',
    'items' => [
        [
            'name' => 'developer_lang_menu_list',
            'menu' => 'developerlangmenulist',
            'url' => '/developer/lang/menu/list'
        ], [
            'name' => 'developer_lang_menu_add',
            'menu' => 'developerlangmenuadd',
            'url' => '/developer/lang/menu/add'
        ], [
            'name' => 'developer_lang_pages_list',
            'menu' => 'developerlangpageslist',
            'url' => '/developer/lang/pages/list'
        ], [
            'name' => 'developer_lang_pages_add',
            'menu' => 'developerlangpagesadd',
            'url' => '/developer/lang/pages/add'
        ]
    ]
]); ?><?php if (isset($__componentOriginal629642e31854f2f3c320339cf9ca8b7a9b63fe21)): ?>
<?php $component = $__componentOriginal629642e31854f2f3c320339cf9ca8b7a9b63fe21; ?>
<?php unset($__componentOriginal629642e31854f2f3c320339cf9ca8b7a9b63fe21); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

<?php $__env->startComponent('menu.menu-item', [
    'name' => 'developer_permissions',
    'icon' => 'icon-key-4',
    'menu' => 'permissions',
    'url' => '/developer/permissions'
]); ?><?php if (isset($__componentOriginal6d24f37cb7e6d98d46a220195dece646fa7436ce)): ?>
<?php $component = $__componentOriginal6d24f37cb7e6d98d46a220195dece646fa7436ce; ?>
<?php unset($__componentOriginal6d24f37cb7e6d98d46a220195dece646fa7436ce); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->startComponent('menu.menu-rolled', [
    'nameItem' => 'settings',
    'icon' => 'icon-cog-alt',
    'name' => 'developer_settings',
    'items' => [
        [
            'name' => 'developer_settings_main',
            'menu' => 'settingsmain',
            'url' => '/developer/settings/main'
        ], [
           'name' => 'developer_settings_pages',
           'menu' => 'settingspages',
           'url' => '/developer/settings/pages'
        ], [
           'name' => 'developer_settings_buttons',
           'menu' => 'settingsbuttons',
           'url' => '/developer/settings/buttons'
        ]
    ]
]); ?><?php if (isset($__componentOriginal629642e31854f2f3c320339cf9ca8b7a9b63fe21)): ?>
<?php $component = $__componentOriginal629642e31854f2f3c320339cf9ca8b7a9b63fe21; ?>
<?php unset($__componentOriginal629642e31854f2f3c320339cf9ca8b7a9b63fe21); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH D:\OSPanel\domains\botV2\resources\views/developer/menu.blade.php ENDPATH**/ ?>