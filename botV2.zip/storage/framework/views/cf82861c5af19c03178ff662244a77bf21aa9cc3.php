<a href="<?php echo e($url); ?>">
    <li class="item-menu <?php echo e($menu); ?>">
        <div>
            <div>
                <i class="<?php echo e($icon); ?>"></i> <span><?php echo app('translator')->get('menu.'.$name); ?></span>
            </div>
            <div></div>
        </div>
    </li>
</a>
<?php /**PATH D:\OSPanel\domains\bot_laravel_8\resources\views/menu/menu-item.blade.php ENDPATH**/ ?>