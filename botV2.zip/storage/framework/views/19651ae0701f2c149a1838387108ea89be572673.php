<?php $__env->startSection("title"); ?>
    <?php echo app('translator')->get('pages.moderators_add'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("h3"); ?>
    <h3><?php echo app('translator')->get('pages.moderators_add'); ?></h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("main"); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/moderators.css')); ?>">

    <form action="<?php echo e(route('moderators-save-add')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div>
            <label for="login"><?php echo app('translator')->get('pages.login'); ?>:</label>
            <input type="text" name="login" id="login">
        </div>
        <div>
            <label for="password"><?php echo app('translator')->get('pages.password'); ?>:</label>
            <input type="password" name="password" id="password">
        </div>
        <div>
            <label for="name"><?php echo app('translator')->get('pages.name'); ?>:</label>
            <input type="text" name="name" id="name">
        </div>
        <br>
        <div>
            <input type="submit" value="<?php echo app('translator')->get('pages.add'); ?>" class="button">
        </div>
    </form>
<?php $__env->stopSection(); ?>



<?php echo $__env->make("admin.template", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\botV2\resources\views/admin/moderators/add.blade.php ENDPATH**/ ?>