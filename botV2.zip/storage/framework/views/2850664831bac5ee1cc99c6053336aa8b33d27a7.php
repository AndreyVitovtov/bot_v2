<?php $__env->startSection("title"); ?>
    <?php echo app('translator')->get('pages.statistics'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("h3"); ?>
    <h3><?php echo app('translator')->get('pages.statistics'); ?></h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("main"); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/statistics.css')); ?>">

    <?php $__currentLoopData = $statistics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="chart_statistics_2">
            <div id="chart_<?php echo e($key); ?>"></div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <script>
        let statistics = {};
        <?php $__currentLoopData = $statistics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            statistics['<?php echo e($key); ?>'] = <?php echo json_encode($value); ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    //Messengers
        chart.options.title = "<?php echo app('translator')->get('pages.statistics_count_users_messengers'); ?>";
        chart.data = [
            ['', 'Telegram', 'Viber'],
            ["<?php echo app('translator')->get('pages.statistics_users_count'); ?>", statistics.messengers.Telegram, statistics.messengers.Viber]
        ];
        chart.drawBar('chart_messengers');

    //Countries
        statistics.countries.unshift(['Country', 'Count']);
        chart.options.title = "<?php echo app('translator')->get('pages.statistics_count_users'); ?>";
        chart.data = statistics.countries;
        chart.drawPie('chart_countries');

    //Visits
        statistics.visits.unshift(['Date', "<?php echo app('translator')->get('pages.statistics_count'); ?>"]);
        chart.options.title = "<?php echo app('translator')->get('pages.statistics_count_users_visits'); ?>";
        chart.data = statistics.visits;
        chart.drawColumn('chart_visits');
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("admin.template", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\botV2\resources\views/admin/statistics/statistics.blade.php ENDPATH**/ ?>