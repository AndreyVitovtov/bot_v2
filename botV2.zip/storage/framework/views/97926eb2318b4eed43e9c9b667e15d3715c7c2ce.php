<?php $__env->startSection("title"); ?>
    <?php echo app('translator')->get('pages.mailing'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("h3"); ?>
    <h3><?php echo app('translator')->get('pages.mailing'); ?></h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("main"); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/mailing.css')); ?>">

    <div class="mailing">
        <form action="/admin/mailing/send" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div>
                <label><?php echo app('translator')->get('pages.mailing_select_country'); ?></label>
            </div>
            <div>
                <select name="country" class="country_mailing">
                    <option value="all"><?php echo app('translator')->get('pages.mailing_all'); ?></option>
                    <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>"><?php echo e($country); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div>
                <label><?php echo app('translator')->get('pages.mailing_text_message'); ?></label>
            </div>
            <div>
                <textarea name="text" <?php echo e($disable); ?>></textarea>
            </div>
            <div>
                <label><?php echo app('translator')->get('pages.image'); ?>:</label>
            </div>
            <div>
                <input type="file" name="image" accept="image/jpeg,image/png,image/gif">
            </div>
            <div><?php echo app('translator')->get('pages.or'); ?></div>
            <div>
                <input type="url" name="url_image" placeholder="<?php echo app('translator')->get('pages.url_image'); ?>">
            </div>
            <div>
                <label><?php echo app('translator')->get('pages.mailing_messenger'); ?></label>
            </div>
            <div>
                <input type="radio" name="messenger" value="%" id="all_messenger" checked>
                <label for="all_messenger"><?php echo app('translator')->get('pages.mailing_all'); ?></label>

                <input type="radio" name="messenger" value="Viber" id="viber">
                <label for="viber">Viber</label>

                <input type="radio" name="messenger" value="Telegram" id="telegram">
                <label for="telegram">Telegram</label>
            </div>

            <div class="block_buttons">
                <button class="button"><?php echo app('translator')->get('pages.send'); ?></button>
                <div>
                    <a href="/admin/mailing/analize">
                        <div class="button">
                            <?php echo app('translator')->get('pages.mailing_analize'); ?>
                        </div>
                    </a>
                    <a href="/admin/mailing/log">
                        <div class="button">
                            <?php echo app('translator')->get('pages.mailing_log'); ?>
                        </div>
                    </a>
                </div>
            </div>
        </form>
        <div>
            <?php if(is_array($task)): ?>
                <div class="mailing-task">
                    <?php echo app('translator')->get('pages.mailing_created'); ?> <?php echo e($task['create']); ?>

                    <br>
                    <?php echo app('translator')->get('pages.mailing_sending'); ?> ≈
                    <?php if($task['start'] > $task['count']): ?>
                        <?php echo e($task['count']); ?>

                    <?php else: ?>
                        <?php echo e($task['start']); ?>

                    <?php endif; ?>
                    <?php echo app('translator')->get('pages.mailing_of'); ?> <?php echo e($task['count']); ?>

                    <div>
                        <form action="/admin/mailing/cancel" method="POST">
                            <?php echo csrf_field(); ?>
                            <button class="button"><?php echo app('translator')->get('pages.mailing_cancel'); ?></button>
                        </form>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make("admin.template", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\botV2\resources\views/admin/mailing/mailing.blade.php ENDPATH**/ ?>