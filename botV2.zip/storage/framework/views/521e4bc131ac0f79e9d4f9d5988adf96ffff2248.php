<?php $__env->startSection("title"); ?>
    <?php echo app('translator')->get('pages.edit_setting_page'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("h3"); ?>
    <h3><?php echo app('translator')->get('pages.edit_setting_page'); ?></h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("main"); ?>
    <form action="/developer/settings/pages/save" method="POST">
        <input type="hidden" name="id" value="<?php echo e($id); ?>">
        <?php echo csrf_field(); ?>
        <div>
            <label for="name"><?php echo app('translator')->get('pages.name'); ?>:</label>
            <input type="text" name="name" value="<?php echo e($name); ?>" id="name">
        </div>
        <div>
            <label for="text"><?php echo app('translator')->get('pages.text'); ?></label>
            <input type="text" name="text" value="<?php echo e($text); ?>" id="text">
        </div>
        <div>
            <label for="description"><?php echo app('translator')->get('pages.description'); ?></label>
            <input type="text" name="description" value="<?php echo e($description); ?>" id="description">
        </div>
        <div>
            <label for="description_us"><?php echo app('translator')->get('pages.description_us'); ?></label>
            <input type="text" name="description_us" value="<?php echo e($description_us); ?>" id="description_us">
        </div>
        <br>
        <div>
            <input type="submit" value="<?php echo app('translator')->get('pages.save'); ?>" class="button">
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("developer.template", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\botV2\resources\views/developer/settings/edit-pages.blade.php ENDPATH**/ ?>