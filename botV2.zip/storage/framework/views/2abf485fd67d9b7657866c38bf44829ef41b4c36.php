<?php $__env->startSection("title"); ?>
    <?php echo app('translator')->get('pages.request'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("h3"); ?>
    <h3>Request</h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("main"); ?>
    <style>
        textarea {
            width: 100%;
            height: 100px;
            resize: none;
            border: solid 1px #ddd;
        }
    </style>
    <code id="json-renderer" class="json-body"></code>
<br>
<br>
<textarea id="json"></textarea>
<br>
<br>

<?php
    $jsonFull = json_encode(json_decode($json));
?>

<form action="<?php echo e(route('send-request')); ?>" method="POST" id="send_request">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="data" value="<?php echo e($json); ?>">
</form>
<button onclick="Copy()" class="button"><?php echo app('translator')->get('pages.copy_text'); ?></button>
<button form="send_request" class="button"><?php echo app('translator')->get('pages.send_request'); ?></button>

<script>
    let jsonFull = '<?php echo $jsonFull; ?>';
    $('#json-renderer').jsonBrowse(JSON.parse(jsonFull), {withQuotes: true});
    $('textarea').val(jsonFull);

    function Copy() {
        let copyText = document.getElementById("json");
        copyText.select();
        document.execCommand("copy");
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("developer.template", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\botV2\resources\views/developer/request/request-json.blade.php ENDPATH**/ ?>