

<?php $__env->startSection("title"); ?>
    <?php echo app('translator')->get('pages.statistics'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("h3"); ?>
    <h3><?php echo app('translator')->get('pages.statistics'); ?></h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("main"); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/statistics.css')); ?>">
    <script>
        let texts = {};
        texts.count_users_visits = "<?php echo app('translator')->get('pages.statistics_count_users_visits'); ?>";
        texts.date = "<?php echo app('translator')->get('pages.statistics_date'); ?>";
        texts.count = "<?php echo app('translator')->get('pages.statistics_count'); ?>";
        texts.users_count = "<?php echo app('translator')->get('pages.statistics_users_count'); ?>";
        texts.count_users_country = "<?php echo app('translator')->get('pages.statistics_count_users'); ?>";
        texts.count_users_messengers = "<?php echo app('translator')->get('pages.statistics_count_users_messengers'); ?>";
        texts.access_title = "<?php echo app('translator')->get('pages.statistics_access'); ?>";

        let statistics = {};
        <?php $__currentLoopData = $statistics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            statistics['<?php echo e($key); ?>'] = <?php echo json_encode($value); ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        google.load('visualization', '1.0', {'packages': ['corechart'] });
        google.setOnLoadCallback(function() {
            drawChart(statistics, texts);
        });
    </script>

    <?php $__currentLoopData = $statistics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="chart_statistics_2">
            <div id="chart_<?php echo e($key); ?>"></div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("admin.template", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\bot_laravel_8\resources\views/admin/statistics/statistics.blade.php ENDPATH**/ ?>