<?php $__env->startSection("title"); ?>
    PayPal
<?php $__env->stopSection(); ?>

<?php $__env->startSection("h3"); ?>
    <h3>PayPal</h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("main"); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/pay.css')); ?>">

    <div class="payment">
        <div>
            <form action="<?php echo route('admin-paypal-save'); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div>
                    <label for="facilitator">Facilitator:</label>
                    <input type="text"
                           name="facilitator"
                           id="facilitator"
                           value="<?php echo e(isset($facilitator) ? $facilitator : ""); ?>">
                </div>
                <br>
                <div>
                    <input type="submit" value="<?php echo app('translator')->get('pages.save'); ?>" class="button">
                </div>
            </form>
        </div>
        <br>
        <pre>Зарегистрировать "Business Account" на <a href="https://www.sandbox.paypal.com">https://www.sandbox.paypal.com</a></pre>
        <pre>Перейти в "Account Settings", в колонке "BUSINESS PROFILE" выбрать "Notifications".</pre>
        <pre>"Instant payment notifications" -> "update", нажать кнопку "Edit settings"</pre>
        <pre>В поле "Notification URL" вставить адрес: <?php echo e(url('/payment/paypal/handler')); ?></pre>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("admin.template", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\botV2\resources\views/admin/payment/paypal-index.blade.php ENDPATH**/ ?>