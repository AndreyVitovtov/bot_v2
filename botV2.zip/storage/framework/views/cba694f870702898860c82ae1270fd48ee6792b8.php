<?php $__env->startSection("title"); ?>
    <?php echo app('translator')->get('pages.settings_button'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("h3"); ?>
    <h3><?php echo app('translator')->get('pages.settings_button'); ?></h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("main"); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/settings.css')); ?>">

    <div class="settings settings_buttons">
        <form action="<?php echo route('save-view-buttons'); ?>" method="POST">
            <div>
                <div>
                    <div>
                        <label for="background_button"><?php echo app('translator')->get('pages.settings_button_bg_color'); ?></label>
                    </div>
                    <div>
                        <label for="color_text_button"><?php echo app('translator')->get('pages.settings_button_font_color'); ?></label>
                    </div>
                    <div>
                        <label for="size_text_button"><?php echo app('translator')->get('pages.settings_button_font_size'); ?></label>
                    </div>
                </div>
                <div>
                    <div>
                        <input type="color" value="<?php echo e($viewButtons->background); ?>" name="background" id="background_button">
                    </div>
                    <div>
                        <input type="color" value="<?php echo e($viewButtons->color_text); ?>" name="color_text" id="color_text_button">
                    </div>
                    <div>
                        <input type="number" value="<?php echo e($viewButtons->size_text); ?>" name="size_text" id="size_text_button">
                    </div>
                </div>
            </div>
            <input type="submit" value="<?php echo app('translator')->get('pages.save'); ?>" class="button">
            <?php echo csrf_field(); ?>
        </form>
        <br>
        <br>
        <div>
            <form action="<?php echo e(route('buttons-go-lang')); ?>">
                <select name="lang" class="language-go">
                    <option value="0"><?php echo e(DEFAULT_LANGUAGE); ?></option>
                    <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($lang->code); ?>"
                            <?php if($lang->code === $l): ?>
                                selected
                            <?php endif; ?>
                        ><?php echo e(base64_decode($lang->emoji)); ?> <?php echo e($lang->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <br>
                <br>
                <input type="submit" value="<?php echo app('translator')->get('pages.go'); ?>" class="button">
            </form>
        </div>
        <br>
        <div>
            <div class="overflow-X-auto">
                <table border="1">
                    <tr class="head">
                        <td>
                            №
                        </td>
                        <td>
                            <?php echo app('translator')->get('pages.text'); ?>
                        </td>
                        <td>
                            <?php echo app('translator')->get('pages.menu'); ?>
                        </td>
                        <td>
                            <?php echo app('translator')->get('pages.edit'); ?>
                        </td>
                    </tr>
                    <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e(base64_decode($field->text)); ?></td>
    
                            <td><?php echo app('translator')->get('settings_buttons.'.$field->name); ?></td>
                            <td class="actions">
                                <div>
                                    <form action="/admin/settings/buttons/edit" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="id" value="<?php echo e($field->id); ?>">
                                        <input type="hidden" name="lang" value="<?php echo e($l); ?>">
                                        <button>
                                            <i class='icon-pen'></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
            <?php echo e($fields->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("admin.template", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\botV2\resources\views/admin/settings/settings-buttons.blade.php ENDPATH**/ ?>