<span class="rolled-hidden">
    <li class="item-menu" data-item="<?php echo e($nameItem); ?>-hidden">
        <div>
            <div>
                <i class="<?php echo e($icon); ?>"></i> <span><?php echo app('translator')->get('menu.'.$name); ?></span>
            </div>
            <div class="item-menu-open">
                <i class="icon-left-open-mini"></i>
            </div>
        </div>
    </li>
    <li class="<?php echo e($nameItem); ?>-hidden hidden menu-hidden">
        <div class="title"><?php echo app('translator')->get('menu.'.$name); ?></div>
        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e($item['url']); ?>">
                <div class="item <?php echo e($item['menu']); ?>">
                        <i class="icon-record-outline"></i> <?php echo app('translator')->get('menu.'.$item['name']); ?>
                </div>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </li>
</span>
<?php /**PATH D:\OSPanel\domains\bot_laravel_8\resources\views/menu/menu-rolled.blade.php ENDPATH**/ ?>