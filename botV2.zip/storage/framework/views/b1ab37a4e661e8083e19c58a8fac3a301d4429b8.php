

<?php $__env->startSection('main'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/auth.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/fontello.css')); ?>">
    <div class="languages">
        <div>
            <a href="<?php echo e(route('locale', App::getLocale())); ?>">
                <img src="<?php echo e(url('/img/language/'.App::getLocale().'.png')); ?>" alt="">
            </a>
        </div>
        <div class="languages-other">
            <?php if(App::getLocale() == "ru"): ?>
                <a href="<?php echo e(route('locale', 'us')); ?>">
                    <img src="<?php echo e(url('/img/language/us.png')); ?>" alt="">
                </a>
            <?php else: ?>
                <a href="<?php echo e(route('locale', 'ru')); ?>">
                    <img src="<?php echo e(url('/img/language/ru.png')); ?>" alt="">
                </a>
            <?php endif; ?>
        </div>
    </div>
    <h3><b><?php echo app('translator')->get('auth.authorization'); ?></b></h3>
    <div class="auth">
        <form action="<?php echo e(route('login')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div>
                <input type="text" name="login" id="inputLogin" placeholder="<?php echo app('translator')->get('auth.login'); ?>" value="<?php echo e(old('login')); ?>" required autofocus>
                <i class="icon-user-8"></i>
            </div>
            <div>
                <input type="password" name="password" id="inputPassword" placeholder="<?php echo app('translator')->get('auth.password'); ?>">
                <i class="icon-lock-filled"></i>
            </div>
            <button id="login"><?php echo app('translator')->get('auth.sign_in'); ?></button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\bot_laravel_8\resources\views/auth/login.blade.php ENDPATH**/ ?>