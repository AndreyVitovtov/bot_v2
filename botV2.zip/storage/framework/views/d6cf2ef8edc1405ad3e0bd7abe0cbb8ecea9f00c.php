<?php $__env->startSection("title"); ?>
    <?php echo app('translator')->get('pages.settings_edit_page'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("h3"); ?>
    <h3><?php echo app('translator')->get('pages.settings_edit_page'); ?></h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("main"); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/settings.css')); ?>">

    <form action="/admin/settings/pages/save" method="POST">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="id" value="<?php echo e($page->id); ?>">
        <div class="settings">
            <div>
                <label for="text"><?php echo app('translator')->get('pages.text'); ?></label>
                <input type="text" name="text" value="<?php echo e(base64_decode($page->text)); ?>" id="text">
            </div>
            <input type="hidden" name="lang" value="<?php echo e($lang); ?>">
            <div class="block_buttons">
                <input type="submit" value="<?php echo app('translator')->get('pages.save'); ?>" class="button">
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("admin.template", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\botV2\resources\views/admin/settings/settings-pages-edit.blade.php ENDPATH**/ ?>