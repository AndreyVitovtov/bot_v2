<?php $__env->startSection("title"); ?>
    <?php echo app('translator')->get('pages.answers_add'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("h3"); ?>
    <h3><?php echo app('translator')->get('pages.answers_add'); ?></h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("main"); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/answers.css')); ?>">

    <form action="/admin/answers/save" method="POST">
        <?php echo csrf_field(); ?>
        <div class="answers">
            <div>
                <label for="question"><?php echo app('translator')->get('pages.answers_add_option_question'); ?></label>
            </div>
            <div>
                <input type="text" name="question" id="question">
            </div>
            <div>
                <label for="answer"><?php echo app('translator')->get('pages.answers_add_answer_bot'); ?></label>
            </div>
            <div>
                <input type="text" name="answer" id="answer">
            </div>
            <div class="block_buttons">
                <input type="submit" value="<?php echo app('translator')->get('pages.add'); ?>" class="button">
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("admin.template", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\botV2\resources\views/admin/answers/answers-add.blade.php ENDPATH**/ ?>