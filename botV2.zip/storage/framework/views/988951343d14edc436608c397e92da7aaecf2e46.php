<?php $__env->startSection("title"); ?>
    <?php echo app('translator')->get('pages.edit_menu_admin_panel'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("h3"); ?>
    <h3><?php echo app('translator')->get('pages.edit_menu_admin_panel'); ?></h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("main"); ?>
    <style>
        .item-border {
            border: solid 1px #ddd;
            padding: 5px;
            background-color: #fbfbfb;
            transition: 0.1s;
        }

        .item-border:hover {
            background-color: #dcdcdc;
            transition: 0.1s;
        }
    </style>

    <form action="<?php echo e(route('menu-admin-edit-save')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="key" value="<?php echo e($key); ?>">
        <input type="hidden" name="type" value="<?php echo e($menu['type']); ?>">
        <?php if($menu['type'] == 'item'): ?>
            <div>
                <label for="name">Name</label>
                <input type="text" name="name" value="<?php echo e($menu['name']); ?>" id="name">
            </div>
            <div>
                <label for="icon">Icon</label>
                <input type="text" name="icon" value="<?php echo e($menu['icon']); ?>" id="icon">
            </div>
            <div>
                <label for="menu">Menu</label>
                <input type="text" name="menu" value="<?php echo e($menu['menu']); ?>" id="menu">
            </div>
            <div>
                <label for="route">Route</label>
                <input type="text" name="url" value="<?php echo e($menu['url']); ?>" id="route">
            </div>
            <br>
        <?php else: ?>
            <div>
                <label for="nameItem">Name item</label>
                <input type="text" name="nameItem" value="<?php echo e($menu['nameItem']); ?>" id="nameItem">
            </div>
            <div>
                <label for="icon">Icon</label>
                <input type="text" name="icon" value="<?php echo e($menu['icon']); ?>" id="icon">
            </div>
            <div>
                <label for="name">Name</label>
                <input type="text" name="name" value="<?php echo e($menu['name']); ?>" id="name">
            </div>
            <br>
            <label for="items">Items</label>
            <br>
            <?php $__currentLoopData = $menu['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keyItem => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="item-border">
                    <div>
                        <label for="itemName">Item name</label>
                        <input type="text" name="itemName[]" value="<?php echo e($item['name']); ?>" id="itemName">
                    </div>
                    <div>
                        <label for="itemMenu">Item menu</label>
                        <input type="text" name="itemMenu[]" value="<?php echo e($item['menu']); ?>" id="itemMenu">
                    </div>
                    <div>
                        <label for="itemRoute">Item route</label>
                        <input type="text" name="itemUrl[]" value="<?php echo e($item['url']); ?>" id="itemRoute">
                    </div>
                </div>
                <br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div id="menu-items"></div>
            <div class="button" id="add_item">Add item</div>
            <br>
            <br>
        <?php endif; ?>
        <div>
            <input type="submit" value="<?php echo app('translator')->get('pages.save'); ?>" class="button">
        </div>
    </form>


    <script>
        $('body').on('change', 'input[name="type"]', function() {
            if($(this).val() === 'item') {
                $('#rolled').hide();
                $('#item').show();
                $('.m-item').attr('disabled', false);
                $('.m-rolled').attr('disabled', true);
            } else {
                $('#rolled').show();
                $('#item').hide();
                $('.m-item').attr('disabled', true);
                $('.m-rolled').attr('disabled', false);
            }
        });

        $('body').on('click', '#add_item', function() {
            let html = '<div class="item-border">'+
                '<label for="item-name-rolled">Item name</label>'+
                '<input type="text" name="itemName[]" class="m-rolled">'+
                '<br>'+
                '<label for="item-menu-rolled">Item menu</label>'+
                '<input type="text" name="itemMenu[]" class="m-rolled">'+
                '<br>'+
                '<label for="item-route-rolled">Item route</label>'+
                '<input type="text" name="itemUrl[]" class="m-rolled">'+
                '</div><br>';

            $('#menu-items').append(html);
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("developer.template", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\botV2\resources\views/developer/menuAdmin/edit.blade.php ENDPATH**/ ?>