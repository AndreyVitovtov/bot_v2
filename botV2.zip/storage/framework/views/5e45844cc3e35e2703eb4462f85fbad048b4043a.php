<?php $__env->startSection("title"); ?>
    <?php echo app('translator')->get('pages.menu_bot'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("h3"); ?>
    <h3><?php echo app('translator')->get('pages.menu_bot'); ?></h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("main"); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/menu.css')); ?>">
    <script src="<?php echo e(asset('js/developer-panel/edit-menu.js')); ?>"></script>
    <label for="select-menu"><?php echo app('translator')->get('pages.select_menu'); ?></label>
    <select id="select-menu">
        <option value="">--</option>
        <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e(substr($m, 0, -5)); ?>"><?php echo e(substr($m, 0, -5)); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <br>
    <br>
    <div class="example-menu">

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("developer.template", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\botV2\resources\views/developer/menu/list.blade.php ENDPATH**/ ?>