<?php $__env->startSection("title"); ?>
    <?php echo app('translator')->get('pages.moderators_edit'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("h3"); ?>
    <h3><?php echo app('translator')->get('pages.moderators_edit'); ?></h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("main"); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/moderators.css')); ?>">

    <form action="<?php echo e(route('moderators-save-edit')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="id" value="<?php echo e($moderator->id); ?>">
        <div>
            <label for="login"><?php echo app('translator')->get('pages.login'); ?>:</label>
            <input type="text" name="login" value="<?php echo e($moderator->login); ?>" id="login">
        </div>
        <div>
            <label for="password"><?php echo app('translator')->get('pages.password'); ?>:</label>
            <input type="password" name="password" id="password">
        </div>
        <div>
            <label for="name"><?php echo app('translator')->get('pages.name'); ?>:</label>
            <input type="text" name="name" value="<?php echo e($moderator->name); ?>" id="name">
        </div>
        <br>
        <div>
            <input type="submit" value="<?php echo app('translator')->get('pages.save'); ?>" class="button">
        </div>
    </form>
<?php $__env->stopSection(); ?>



<?php echo $__env->make("admin.template", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\botV2\resources\views/admin/moderators/edit.blade.php ENDPATH**/ ?>