

<?php $__env->startSection("title"); ?>
    <?php echo app('translator')->get('pages.moderators'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("h3"); ?>
    <h3><?php echo app('translator')->get('pages.moderators'); ?></h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("main"); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/moderators.css')); ?>">
    <div class="overflow-X-auto">
        <table>
            <tr>
                <td><?php echo app('translator')->get('pages.moderators'); ?></td>
                <td><?php echo app('translator')->get('pages.moderators_actions'); ?></td>
            </tr>
            <?php $__currentLoopData = $moderators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $moderator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($moderator->name); ?></td>
                    <td class="actions">
                        <div>
                            <form action="<?php echo e(route('moderators-edit')); ?>"
                                  method="POST"
                                  id="form-moderators-edit-<?php echo e($moderator->id); ?>">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="id" value="<?php echo e($moderator->id); ?>">
                                <button form="form-moderators-edit-<?php echo e($moderator->id); ?>">
                                    <i class='icon-pen'></i>
                                </button>
                            </form>

                            <form action="<?php echo e(route('moderators-delete')); ?>" method="POST" id="form-delete-<?php echo e($moderator->id); ?>">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="id" value="<?php echo e($moderator->id); ?>">
                                <button form="form-delete-<?php echo e($moderator->id); ?>">
                                    <i class='icon-trash-empty'></i>
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make("admin.template", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\bot_laravel_8\resources\views/admin/moderators/list.blade.php ENDPATH**/ ?>