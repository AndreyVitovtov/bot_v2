<?php
    $menu = json_decode(file_get_contents(public_path('json/menu-admin.json')), true);
?>
<?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name => $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if(auth()->check() && (auth()->user()->id === 1 || auth()->user()->hasPermission($name))): ?>
        <?php if(is_array($m) && $m['type'] === 'item'): ?>
            <?php $__env->startComponent('menu.menu-item', [
                'name' => $m['name'],
                'icon' => $m['icon'],
                'menu' => $m['menu'],
                'url' => route($m['url'])
            ]); ?><?php if (isset($__componentOriginal6d24f37cb7e6d98d46a220195dece646fa7436ce)): ?>
<?php $component = $__componentOriginal6d24f37cb7e6d98d46a220195dece646fa7436ce; ?>
<?php unset($__componentOriginal6d24f37cb7e6d98d46a220195dece646fa7436ce); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
        <?php else: ?>
            <?php
            foreach($m['items'] as &$i) {
                $url = $i['url'];
                $i['url'] = route($url);
            }
            ?>
            <?php $__env->startComponent('menu.menu-rolled', [
                'nameItem' => $m['nameItem'],
                'icon' => $m['icon'],
                'name' => $m['name'],
                'items' => $m['items']
            ]); ?><?php if (isset($__componentOriginal629642e31854f2f3c320339cf9ca8b7a9b63fe21)): ?>
<?php $component = $__componentOriginal629642e31854f2f3c320339cf9ca8b7a9b63fe21; ?>
<?php unset($__componentOriginal629642e31854f2f3c320339cf9ca8b7a9b63fe21); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
        <?php endif; ?>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH D:\OSPanel\domains\botV2\resources\views/admin/menu.blade.php ENDPATH**/ ?>