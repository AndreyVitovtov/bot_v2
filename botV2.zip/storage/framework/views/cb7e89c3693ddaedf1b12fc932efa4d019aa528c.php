

<?php $__env->startSection("title"); ?>
    Qiwi
<?php $__env->stopSection(); ?>

<?php $__env->startSection("h3"); ?>
    <h3>Qiwi</h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("main"); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/pay.css')); ?>">
    <div class="payment">
        <div>
            <form action="<?php echo route('qiwi-save'); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div>
                    <label for="token">Token:</label>
                    <input type="text" name="token" id="token" value="<?php echo e(isset($token) ? $token : ""); ?>">
                </div>
                <div>
                    <label for="webhookId">Webhook id:</label>
                    <input type="text"
                           name="webhookId"
                           id="webhookId"
                           value="<?php echo e(isset($webhookId) ? $webhookId : ""); ?>"
                           placeholder="Не заполнять">
                </div>
                <div>
                    <label for="publicKey">Public key:</label>
                    <input type="text" name="publicKey" id="publicKey" value="<?php echo e(isset($publicKey) ? $publicKey : ""); ?>">
                </div>
                <br>
                <div>
                    <input type="submit" value="Сохранить" class="button">
                </div>
            </form>
        </div>
        <br>
        <pre>Token:</pre>
        <pre><a href="https://qiwi.com/api" target="_blank">https://qiwi.com/api</a></pre>
        <br>
        <pre>Public Key:</pre>
        <pre>Для браузера "Google Chrome"</pre>
        <pre>Перейти на <a href="https://qiwi.com/p2p-admin/transfers/invoice" target="_blank">https://qiwi.com/p2p-admin/transfers/invoice</a>,
Открыть "Панель разработчика" (F12), вкладка "Network", заполнить поля, нажать "Выставить счет".
В панели разработчика в колонке "Name" выбрать "create". Вкладка "Headers", "Request Payload" -> "public_key";
        </pre>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("developer.template", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\botV2\resources\views/developer/payment/qiwi-index.blade.php ENDPATH**/ ?>