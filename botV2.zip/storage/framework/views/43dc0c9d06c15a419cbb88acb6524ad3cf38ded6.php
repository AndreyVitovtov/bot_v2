<?php $__env->startSection("title"); ?>
    <?php echo app('translator')->get('pages.settings_pages'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("h3"); ?>
    <h3><?php echo app('translator')->get('pages.settings_pages'); ?></h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("main"); ?>
    <div class="settings settings_pages">
        <div>
            <div>
                <form action="<?php echo e(route('pages-go-lang')); ?>" method="GET">
                    <div>
                        <select name="lang" class="language-go">
                            <option value="0"><?php echo e(DEFAULT_LANGUAGE); ?></option>
                            <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($lang->code); ?>"
                                    <?php if($lang->code === $l): ?>
                                        selected
                                    <?php endif; ?>
                                ><?php echo e(base64_decode($lang->emoji)); ?> <?php echo e($lang->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <br>
                    <div>
                        <input type="submit" value="<?php echo app('translator')->get('pages.go'); ?>" class="button">
                    </div>
                </form>
            </div>
            <br>
            <div class="overflow-X-auto">
                <table border="1">
                    <tr class="head">
                        <td>
                            №
                        </td>
                        <td>
                            <?php echo app('translator')->get('pages.text'); ?>
                        </td>
                        <td>
                            <?php echo app('translator')->get('pages.description'); ?>
                        </td>
                        <td>
                            <?php echo app('translator')->get('pages.edit'); ?>
                        </td>
                    </tr>
                    <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e(base64_decode($field->text)); ?></td>
    
                            <td><?php echo app('translator')->get('settings_pages.'.$field->name); ?></td>
                            <td class="actions">
                                <div>
                                    <form action="/admin/settings/pages/edit" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="id" value="<?php echo e($field->id); ?>">
                                        <input type="hidden" name="lang" value="<?php echo e($l); ?>">
                                        <button>
                                            <i class='icon-pen'></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
            <?php echo e($fields->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("admin.template", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\botV2\resources\views/admin/settings/settings-pages.blade.php ENDPATH**/ ?>