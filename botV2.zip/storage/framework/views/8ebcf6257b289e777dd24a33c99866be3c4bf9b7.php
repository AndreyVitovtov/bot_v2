

<?php $__env->startSection("title"); ?>
    <?php echo app('translator')->get('pages.log'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("h3"); ?>
    <h3><?php echo app('translator')->get('pages.log'); ?></h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("main"); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/mailing.css')); ?>">
    <div class="log">
        <?php echo str_replace('=>' , "<i class='icon-right-small'></i>", $log); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("admin.template", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\botV2\resources\views/admin/mailing/mailing-log.blade.php ENDPATH**/ ?>