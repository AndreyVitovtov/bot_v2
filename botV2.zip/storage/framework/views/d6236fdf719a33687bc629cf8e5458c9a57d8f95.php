

<?php $__env->startSection("title"); ?>
    Основные настройки
<?php $__env->stopSection(); ?>

<?php $__env->startSection("h3"); ?>
    <h3>Основные настройки</h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("main"); ?>
    <table>
        <tr>
            <td>№</td>
            <td>Имя поля</td>
            <td>Префикс</td>
            <td>Значение</td>
            <td>Тип</td>
            <td>Действия</td>
        </tr>
        <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($field['name']); ?></td>
                <td><?php echo e(mb_strtoupper($field['prefix'])); ?></td>
                <td><?php echo e(mb_strimwidth($field['value'], 0, 100, "...")); ?></td>
                <td><?php echo e($field['type']); ?></td>
                <td class="actions">
                    <div>
                        <form action="/developer/settings/main/edit" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" value="<?php echo e($field['id']); ?>">
                            <button>
                                <i class='icon-pen'></i>
                            </button>
                        </form>
                        <form action="/developer/settings/main/delete" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" value="<?php echo e($field['id']); ?>">
                            <button>
                                <i class='icon-trash-empty'></i>
                            </button>
                        </form>
                    </div>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <br>
    <form action="/developer/settings/main/add" method="POST">
        <?php echo csrf_field(); ?>
        <div>
            <label for="name">Имя поля:</label>
            <input type="text" name="name" id="name">
        </div>
        <div>
            <label for="name_us">Имя поля на английском:</label>
            <input type="text" name="name_us" id="name_us">
        </div>
        <div>
            <label for="prexix">Префикс</label>
            <input type="text" name="prefix" id="prefix">
        </div>
        <div>
            <label for="value">Значение</label>
            <input type="text" name="value" id="value">
        </div>
        <div>
            <label for="type">Тип</label>
            <select name="type" id="type">
                <option value="number">Number</option>
                <option value="text">Text</option>
                <option value="date">Date</option>
            </select>
        </div>
        <br>
        <div>
            <input type="submit" value="Добавить" class="button">
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("developer.template", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\bot_laravel_8\resources\views/developer/settings/settings-main.blade.php ENDPATH**/ ?>