<?php $__env->startSection("title"); ?>
    <?php echo app('translator')->get('pages.languages_add'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("h3"); ?>
    <h3><?php echo app('translator')->get('pages.languages_add'); ?></h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("main"); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/languages.css')); ?>">

        <form action="<?php echo e(route('languages-add-save')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="lang">
                <div>
                    <label for="name"><?php echo app('translator')->get('pages.languages_name'); ?></label>
                </div>
                <div>
                    <input type="text" name="name" id="name">
                </div>
                <div>
                    <label for="code"><?php echo app('translator')->get('pages.languages_code'); ?></label>
                </div>
                <div>
                    <input type="text" name="code" id="code">
                </div>
                <div>
                    <label for="emoji"><?php echo app('translator')->get('pages.languages_emoji'); ?></label>
                </div>
                <div>
                    <input type="text" name="emoji" id="emoji">
                </div>
                <div class="block_buttons">
                    <input type="submit" value="<?php echo app('translator')->get('pages.add'); ?>" class="button">
                </div>
            </div>
        </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("admin.template", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\botV2\resources\views/admin/languages/add.blade.php ENDPATH**/ ?>