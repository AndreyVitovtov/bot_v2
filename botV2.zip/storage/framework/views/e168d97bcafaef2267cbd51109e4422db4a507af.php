<!doctype html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent("title"); ?> | <?php echo app('translator')->get('template.title'); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/developer.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/fontello.css')); ?>">
    <link rel="shortcut icon" href="<?php echo e(asset('img/favicon.ico')); ?>" type="image/x-icon">
    <script src="<?php echo e(asset('js/jquery-3.4.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.cookie.js')); ?>"></script>
    <script src="<?php echo e(asset('js/common.js')); ?>"></script>
    <script src="<?php echo e(asset('https://www.gstatic.com/charts/loader.js')); ?>"></script>
    <script src="<?php echo e(asset('js/charts/Chart.js')); ?>"></script>

</head>
<body>
<div class="pop-up-window">
</div>
<header>
    <section class="left-panel <?php if(isset($_COOKIE['rolled']) && $_COOKIE['rolled'] === 'true'): ?> rolled <?php endif; ?>">
        <?php if(isset($_COOKIE['rolled']) && $_COOKIE['rolled'] === 'true'): ?>
            <?php echo e(Lang::get('pages.bot_name')[0]); ?>

        <?php else: ?>
            <?php echo app('translator')->get('pages.bot_name'); ?>
        <?php endif; ?>
    </section>
    <section class="right-panel <?php if(isset($_COOKIE['rolled']) && $_COOKIE['rolled'] === 'true'): ?> rolled <?php endif; ?>">
        <nav class="open-menu mob-hidden">
            <i class="icon-menu"></i>
        </nav>
        <nav class="open-menu-mob pc-hidden">
            <i class="icon-menu"></i>
        </nav>
        <div class="right-panel-lang-user">
            <div class="languages">
                <div>
                    <a href="<?php echo e(route('locale', App::getLocale())); ?>">
                        <img src="<?php echo e(url('/img/language/'.App::getLocale().'.png')); ?>" alt="">
                    </a>
                </div>
                <div class="languages-other">
                    <?php if(App::getLocale() == "ru"): ?>
                        <a href="<?php echo e(route('locale', 'us')); ?>">
                            <img src="<?php echo e(url('/img/language/us.png')); ?>" alt="">
                        </a>
                    <?php else: ?>
                        <a href="<?php echo e(route('locale', 'ru')); ?>">
                            <img src="<?php echo e(url('/img/language/ru.png')); ?>" alt="">
                        </a>
                    <?php endif; ?>
                </div>
            </div>
            <nav class="open-user-menu">
                <img src="<?php echo e(asset('img/avatar5.png')); ?>" alt="avatar">
                <span>
                    <?php echo e(Auth::user()->name); ?>

            </span>
            </nav>
        </div>
        <div class="dropdown-menu">
            <img src="<?php echo e(asset('img/avatar5.png')); ?>" alt="avatar">
            <div class="title">
                <div>
                    <?php echo e(Auth::user()->name); ?>

                </div>
            </div>
            <div class="dropdown-menu-nav">
                <div>
                    <form action="/admin/settings" method="POST">
                        <?php echo csrf_field(); ?>
                        <button class="button user-settings"><?php echo app('translator')->get('template.top_panel_settings'); ?></button>
                    </form>
                </div>
                <div>
                    <form action="/logout">
                        <button data-go="exit" class="button"><?php echo app('translator')->get('template.top_panel_log_off'); ?></button>
                    </form>
                </div>
            </div>
        </div>
    </section>
</header>
<main>
    <section class="sidebar no-active <?php if(isset($_COOKIE['rolled']) && $_COOKIE['rolled'] === 'true'): ?> rolled <?php endif; ?>">
        <div class="user-panel">
            <div class="avatar-user-panel"></div>
            <span>
                <?php echo app('translator')->get('template.left_panel_administrator'); ?>
            </span>
        </div>
        <ul class="sidebar-menu">
            <li class="header"><?php echo app('translator')->get('template.left_panel_menu'); ?></li>
            <?php echo $__env->make('admin.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </ul>
    </section>
    <section class="content">
        <div class="container">
            <?php echo $__env->yieldContent("h3"); ?>
            <div>
                <?php echo $__env->yieldContent("main"); ?>
            </div>
        </div>
        <footer>
            Copyright © 2021 <a href="https://vitovtov.top" target="_blank">vitovtov.top</a>
        </footer>
    </section>
</main>

<?php if(isset($menuItem)): ?>
    <script>
        $('.item-menu').removeClass('active');
        $('main section.sidebar .menu-hidden div').removeClass('active');
        $('.<?php echo e($menuItem); ?>').addClass('active');
        $('.<?php echo e($menuItem); ?>').parents('span.rolled-hidden').children('li.item-menu').addClass('active');
        $('.<?php echo e($menuItem); ?>').parents('li').addClass('menu-active');
        $('.<?php echo e($menuItem); ?>').parents('li').toggle();
    </script>
<?php endif; ?>

<?php if(isset($notification)): ?>
    <script>
        setTimeout(function() {
            popUpWindow('<?php echo e($notification); ?>')
        }, 300);
    </script>
<?php endif; ?>

<script>
    $('body').on('click', '.open-menu', function() {
        rolled();
    });

    if($.cookie('rolled') === 'true') {
        $('header .right-panel').css('width: calc( 100% - 50px )');
        $('main section.sidebar .menu-hidden.menu-active').hide();
    }

    function rolled() {
        if($('.sidebar').is('.rolled')) {
            $('header .left-panel').html('<?php echo app('translator')->get('pages.bot_name'); ?>');
            $('main section.sidebar .menu-hidden.menu-active').show();

            $.cookie('rolled', 'false', {path: '/'});
        }
        else {
            $('header .left-panel').html('<?php echo e(Lang::get('pages.bot_name')[0]); ?>');
            $('header .right-panel').css('width: calc( 100% - 50px )');
            $('main section.sidebar .menu-hidden.menu-active').hide();

            $.cookie('rolled', 'true', {path: '/'});
        }
        $('.sidebar').toggleClass('rolled');
        $('header .left-panel').toggleClass('rolled');
        $('header .right-panel').toggleClass('rolled');
    }
</script>
</body>
</html>
<?php /**PATH D:\OSPanel\domains\botV2\resources\views/admin/template.blade.php ENDPATH**/ ?>