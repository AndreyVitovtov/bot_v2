<?php $__env->startSection("title"); ?>
    <?php echo app('translator')->get('pages.permissions'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("h3"); ?>
    <h3><?php echo app('translator')->get('pages.permissions'); ?></h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("main"); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/permissions.css')); ?>">
    <table>
        <tr>
            <td>
                <?php echo app('translator')->get('pages.permission_name'); ?>
            </td>
            <td>
                <?php echo app('translator')->get('pages.delete'); ?>
            </td>
        </tr>
    <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="tal">
                <?php echo e($permission->name); ?>

            </td>
            <td class="actions tac">
                <form action="<?php echo e(route('permission-delete')); ?>" method="POST" id="delete_permission_<?php echo e($permission->id); ?>">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id" value="<?php echo e($permission->id); ?>">
                </form>
                <button form="delete_permission_<?php echo e($permission->id); ?>"><i class="icon-trash-empty"></i></button>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <br>
    <form action="<?php echo e(route('permission-add')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div>
            <label for=""><?php echo app('translator')->get('pages.permission_name'); ?>:</label>
            <input type="text" name="permission">
        </div>
        <br>
        <div>
            <input type="submit" value="<?php echo app('translator')->get('pages.add'); ?>" class="button">
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("developer.template", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\botV2\resources\views/developer/permissions/index.blade.php ENDPATH**/ ?>