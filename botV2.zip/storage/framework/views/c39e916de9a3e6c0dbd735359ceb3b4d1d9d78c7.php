<?php $__env->startSection("title"); ?>
    <?php echo app('translator')->get('pages.edit_settings_buttons'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("h3"); ?>
    <h3><?php echo app('translator')->get('pages.edit_settings_buttons'); ?></h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("main"); ?>
    <form action="/developer/settings/buttons/save" method="POST">
        <input type="hidden" name="id" value="<?php echo e($id); ?>">
        <?php echo csrf_field(); ?>
        <div>
            <label for="name"><?php echo app('translator')->get('pages.name'); ?>:</label>
            <input type="text" name="name" value="<?php echo e($name); ?>" id="name">
        </div>
        <div>
            <label for="text"><?php echo app('translator')->get('pages.text'); ?></label>
            <input type="text" name="text" value="<?php echo e($text); ?>" id="text">
        </div>
        <div>
            <label for="menu"><?php echo app('translator')->get('pages.menu'); ?></label>
            <input type="text" name="menu" value="<?php echo e($menu); ?>" id="menu">
        </div>
        <div>
            <label for="menu_us"><?php echo app('translator')->get('pages.menu_us'); ?></label>
            <input type="text" name="menu_us" value="<?php echo e($menu_us); ?>" id="menu_us">
        </div>
        <br>
        <div>
            <input type="submit" value="<?php echo app('translator')->get('pages.save'); ?>" class="button">
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("developer.template", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\botV2\resources\views/developer/settings/edit-buttons.blade.php ENDPATH**/ ?>