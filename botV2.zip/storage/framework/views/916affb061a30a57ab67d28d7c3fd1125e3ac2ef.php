<?php if(auth()->check() && (auth()->user()->id === 1 || auth()->user()->hasPermission('statistics'))): ?>
    <?php $__env->startComponent('menu.menu-item', [
        'name' => 'statistics',
        'icon' => 'icon-gauge',
        'menu' => 'statistics',
        'url' => '/admin']); ?>
    <?php if (isset($__componentOriginal6d24f37cb7e6d98d46a220195dece646fa7436ce)): ?>
<?php $component = $__componentOriginal6d24f37cb7e6d98d46a220195dece646fa7436ce; ?>
<?php unset($__componentOriginal6d24f37cb7e6d98d46a220195dece646fa7436ce); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

<?php if(auth()->check() && (auth()->user()->id === 1 || auth()->user()->hasPermission('users'))): ?>
    <?php $__env->startComponent('menu.menu-item', [
        'name' => 'users',
        'icon' => 'icon-users-3',
        'menu' => 'users',
        'url' => '/admin/users']); ?>
    <?php if (isset($__componentOriginal6d24f37cb7e6d98d46a220195dece646fa7436ce)): ?>
<?php $component = $__componentOriginal6d24f37cb7e6d98d46a220195dece646fa7436ce; ?>
<?php unset($__componentOriginal6d24f37cb7e6d98d46a220195dece646fa7436ce); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

<?php if(auth()->check() && (auth()->user()->id === 1 || auth()->user()->hasPermission('mailing'))): ?>
    <?php $__env->startComponent('menu.menu-item', [
        'name' => 'mailing',
        'icon' => 'icon-mail-4',
        'menu' => 'mailing',
        'url' => '/admin/mailing']); ?>
    <?php if (isset($__componentOriginal6d24f37cb7e6d98d46a220195dece646fa7436ce)): ?>
<?php $component = $__componentOriginal6d24f37cb7e6d98d46a220195dece646fa7436ce; ?>
<?php unset($__componentOriginal6d24f37cb7e6d98d46a220195dece646fa7436ce); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

<?php if(auth()->check() && (auth()->user()->id === 1 || auth()->user()->hasPermission('moderators'))): ?>
    <?php $__env->startComponent('menu.menu-rolled', [
        'nameItem' => 'moderators',
        'icon' => 'icon-users-2',
        'name' => 'moderators',
        'items' => [[
               'name' => 'moderators_list',
               'menu' => 'moderatorslist',
               'url' => '/admin/moderators'
            ],[
               'name' => 'moderators_add',
               'menu' => 'moderatorsadd',
               'url' => '/admin/moderators/add'
            ],[
               'name' => 'moderators_permissions',
               'menu' => 'moderatorspermissions',
               'url' => '/admin/moderators/permissions'
            ]
        ]]); ?>
    <?php if (isset($__componentOriginal629642e31854f2f3c320339cf9ca8b7a9b63fe21)): ?>
<?php $component = $__componentOriginal629642e31854f2f3c320339cf9ca8b7a9b63fe21; ?>
<?php unset($__componentOriginal629642e31854f2f3c320339cf9ca8b7a9b63fe21); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

<?php if(auth()->check() && (auth()->user()->id === 1 || auth()->user()->hasPermission('languages'))): ?>
    <?php $__env->startComponent('menu.menu-rolled', [
        'nameItem' => 'languages',
        'icon' => 'icon-language-1',
        'name' => 'languages',
        'items' => [[
                'name' => 'languages_list',
                'menu' => 'languageslist',
                'url' => '/admin/languages/list'
            ],[
               'name' => 'languages_add',
               'menu' => 'languagesadd',
               'url' => '/admin/languages/add'
            ]
        ]]); ?>
    <?php if (isset($__componentOriginal629642e31854f2f3c320339cf9ca8b7a9b63fe21)): ?>
<?php $component = $__componentOriginal629642e31854f2f3c320339cf9ca8b7a9b63fe21; ?>
<?php unset($__componentOriginal629642e31854f2f3c320339cf9ca8b7a9b63fe21); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

<?php if(auth()->check() && (auth()->user()->id === 1 || auth()->user()->hasPermission('contacts'))): ?>
    <?php $__env->startComponent('menu.menu-rolled', [
        'nameItem' => 'contacts',
        'icon' => 'icon-book',
        'name' => 'contacts',
        'items' => [[
                'name' => 'contacts_general',
                'menu' => 'contactsgeneral',
                'url' => '/admin/contacts/general'
            ],
            [
               'name' => 'contacts_access',
               'menu' => 'contactsaccess',
               'url' => '/admin/contacts/access'
            ],
            [
               'name' => 'contacts_advertising',
               'menu' => 'contactsadvertising',
               'url' => '/admin/contacts/advertising'
            ],[
               'name' => 'contacts_offers',
               'menu' => 'contactsoffers',
               'url' => '/admin/contacts/offers'
            ]
        ]]); ?>
    <?php if (isset($__componentOriginal629642e31854f2f3c320339cf9ca8b7a9b63fe21)): ?>
<?php $component = $__componentOriginal629642e31854f2f3c320339cf9ca8b7a9b63fe21; ?>
<?php unset($__componentOriginal629642e31854f2f3c320339cf9ca8b7a9b63fe21); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

<?php if(auth()->check() && (auth()->user()->id === 1 || auth()->user()->hasPermission('answers'))): ?>
    <?php $__env->startComponent('menu.menu-rolled', [
        'nameItem' => 'answers',
        'icon' => 'icon-help-1',
        'name' => 'answers',
        'items' => [[
                'name' => 'answers_list',
                'menu' => 'answerslist',
                'url' => '/admin/answers/list'
            ],[
               'name' => 'answers_add',
               'menu' => 'answersadd',
               'url' => '/admin/answers/add'
            ]
        ]]); ?>
    <?php if (isset($__componentOriginal629642e31854f2f3c320339cf9ca8b7a9b63fe21)): ?>
<?php $component = $__componentOriginal629642e31854f2f3c320339cf9ca8b7a9b63fe21; ?>
<?php unset($__componentOriginal629642e31854f2f3c320339cf9ca8b7a9b63fe21); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>



























<?php if(auth()->check() && (auth()->user()->id === 1 || auth()->user()->hasPermission('settings'))): ?>
    <?php $__env->startComponent('menu.menu-rolled', [
        'nameItem' => 'settings',
        'icon' => 'icon-cog-alt',
        'name' => 'settings',
        'items' => [
            [
            'name' => 'settings_main',
            'menu' => 'settingsmain',
            'url' => '/admin/settings/main'
            ],
            [
               'name' => 'settings_pages',
               'menu' => 'settingspages',
               'url' => '/admin/settings/pages'
            ],[
               'name' => 'settings_buttons',
               'menu' => 'settingsbuttons',
               'url' => '/admin/settings/buttons'
            ]
        ]]); ?>
    <?php if (isset($__componentOriginal629642e31854f2f3c320339cf9ca8b7a9b63fe21)): ?>
<?php $component = $__componentOriginal629642e31854f2f3c320339cf9ca8b7a9b63fe21; ?>
<?php unset($__componentOriginal629642e31854f2f3c320339cf9ca8b7a9b63fe21); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH D:\OSPanel\domains\bot_laravel_8\resources\views/admin/menu.blade.php ENDPATH**/ ?>