<?php $__env->startSection("title"); ?>
    <?php echo app('translator')->get('pages.edit_settings_main'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("h3"); ?>
    <h3><?php echo app('translator')->get('pages.edit_settings_main'); ?></h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("main"); ?>
    <form action="/developer/settings/main/save" method="POST">
        <input type="hidden" name="id" value="<?php echo e($id); ?>">
        <?php echo csrf_field(); ?>
        <div>
            <label for="name"><?php echo app('translator')->get('pages.field_name'); ?>:</label>
            <input type="text" name="name" value="<?php echo e($name); ?>" id="name">
        </div>
        <div>
            <label for="name"><?php echo app('translator')->get('pages.field_name_us'); ?>:</label>
            <input type="text" name="name_us" value="<?php echo e($name_us); ?>" id="name_us">
        </div>
        <div>
            <label for="prexix"><?php echo app('translator')->get('pages.prefix'); ?></label>
            <input type="text" name="prefix" value="<?php echo e($prefix); ?>" id="prefix">
        </div>
        <div>
            <label for="value"><?php echo app('translator')->get('pages.value'); ?></label>
            <input type="text" name="value" value="<?php echo e($value); ?>" id="value">
        </div>
        <div>
            <label for="type"><?php echo app('translator')->get('pages.type'); ?></label>
            <select name="type" id="type">
                <option value="number" <?php if($type == "number"): ?> selected <?php endif; ?>>Number</option>
                <option value="text" <?php if($type == "text"): ?> selected <?php endif; ?>>Text</option>
                <option value="date" <?php if($type == "date"): ?> selected <?php endif; ?>>Date</option>
            </select>
        </div>
        <br>
        <div>
            <input type="submit" value="<?php echo app('translator')->get('pages.save'); ?>" class="button">
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("developer.template", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\botV2\resources\views/developer/settings/edit-main.blade.php ENDPATH**/ ?>