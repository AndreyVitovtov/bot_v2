<?php $__env->startSection("title"); ?>
    <?php echo app('translator')->get('pages.users_user_profile'); ?> "<?php echo e($profile->username); ?>"
<?php $__env->stopSection(); ?>

<?php $__env->startSection("h3"); ?>
    <h3><?php echo app('translator')->get('pages.users_user_profile'); ?> "<?php echo e($profile->username); ?>"</h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("main"); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/users.css')); ?>">

    <style>
        main .users label.access:after {
            content: '<?php echo app('translator')->get('pages.users_user_no'); ?>';
            text-align: center;
            line-height: 26px;
            color: #fff;
            position: absolute;
            width: 35px;
            height: 30px;
            background-color: #808080;
            border-radius: 5px 0 0 5px;
            border: solid 1px #808080;
            box-sizing: border-box;
            left: -1px;
            top: -2px;
        }

        main .users #access:checked + label.access:before {
            content: '<?php echo app('translator')->get('pages.users_user_yes'); ?>';
            text-align: center;
            line-height: 26px;
            color: #fff;
            position: absolute;
            width: 35px;
            height: 30px;
            background-color: #3c8dbc;
            border-radius: 0 5px 5px 0;
            border: solid 1px #3c8dbc;
            box-sizing: border-box;
            right: -2px;
            top: -2px;
        }
    </style>

    <div class="users">
        <div class="overflow-X-auto">
            <table>
                <tr>
                    <td><?php echo app('translator')->get('pages.users_username'); ?></td>
                    <td><?php echo e($profile->username); ?></td>
                </tr>
                <tr>
                    <td>ID Chat:</td>
                    <td><?php echo e($profile->chat); ?></td>
                </tr>
                <tr>
                    <td><?php echo app('translator')->get('pages.users_date'); ?></td>
                    <td><?php echo e($profile->date); ?> <?php echo e($profile->time); ?></td>
                </tr>
            </table>
        </div>
        <br>
        <hr>
        <br>






















        <div>
            <form action="<?php echo e(route('user-send-message')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="id" value="<?php echo e($profile->id); ?>">
                <div>
                    <label for="message"><?php echo app('translator')->get('pages.message'); ?></label>
                </div>
                <div>
                    <textarea name="message" id="message"></textarea>
                </div>
                <br>
                <div>
                    <input type="submit" value="<?php echo app('translator')->get('pages.send'); ?>" class="button">
                </div>
            </form>
        </div>
    </div>

    <script>
        $('#access').change(function() {
            $('#access-form').submit();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("admin.template", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\botV2\resources\views/admin/users/user-profile.blade.php ENDPATH**/ ?>