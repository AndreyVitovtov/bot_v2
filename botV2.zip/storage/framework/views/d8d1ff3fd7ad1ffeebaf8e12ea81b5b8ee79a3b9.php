<?php $__env->startSection("title"); ?>
    <?php echo app('translator')->get('pages.menu_list'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("h3"); ?>
    <h3><?php echo app('translator')->get('pages.menu_list'); ?></h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("main"); ?>
    <table>
        <tr>
            <td>Key</td>
            <td>Ru</td>
            <td>Us</td>
            <td><?php echo app('translator')->get('pages.actions'); ?></td>
        </tr>
        <?php $__currentLoopData = $textsRu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $text): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td style="text-align: left;"><?php echo e($key); ?></td>
                <td><?php echo e($text); ?></td>
                <td><?php echo e($textsUs[$key]); ?></td>
                <td class="actions">
                    <div>
                        <form action="<?php echo e(route('lang-menu-edit')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="key" value="<?php echo e($key); ?>">
                            <button>
                                <i class='icon-pen'></i>
                            </button>
                        </form>
                        <form action="<?php echo e(route('lang-menu-delete')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="key" value="<?php echo e($key); ?>">
                            <button>
                                <i class='icon-trash-empty'></i>
                            </button>
                        </form>
                    </div>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("developer.template", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\botV2\resources\views/developer/lang/menu-list.blade.php ENDPATH**/ ?>