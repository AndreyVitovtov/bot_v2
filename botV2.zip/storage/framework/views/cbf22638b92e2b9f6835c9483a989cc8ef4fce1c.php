<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent("title"); ?> | <?php echo app('translator')->get('pages.developer'); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/fontello.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/developer.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/jquery.json-browse.css')); ?>">
    <link rel="shortcut icon" href="<?php echo e(asset('img/favicon.ico')); ?>" type="image/x-icon">
    <script src="<?php echo e(asset('js/jquery-3.4.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/common.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.cookie.js')); ?>"></script>
    <script src="<?php echo e(asset('https://www.gstatic.com/charts/loader.js')); ?>"></script>
    <script src="<?php echo e(asset('js/charts/Chart.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.json-browse.js')); ?>"></script>

    <?php if(isset($menuItem)): ?>
        <script>
            window.onload = function() {
                $('.item-menu').removeClass('active');
                $('main section.sidebar .menu-hidden div').removeClass('active');
                $('.<?php echo e($menuItem); ?>').addClass('active');
                $('.<?php echo e($menuItem); ?>').parents('span.rolled-hidden').children('li.item-menu').addClass('active');
                $('.<?php echo e($menuItem); ?>').parents('li').addClass('menu-active');
                $('.<?php echo e($menuItem); ?>').parents('li').toggle();
            };
        </script>
    <?php endif; ?>
</head>
<body>
<header>
    <section class="left-panel">
        <?php echo app('translator')->get('pages.bot_name'); ?>
    </section>
    <section class="right-panel">



        <div></div>
        <div class="right-panel-lang-user">
            <div class="languages">
                <div>
                    <a href="<?php echo e(route('locale', App::getLocale())); ?>">
                        <img src="<?php echo e(url('/img/language/'.App::getLocale().'.png')); ?>" alt="">
                    </a>
                </div>
                <div class="languages-other">
                    <?php if(App::getLocale() == "ru"): ?>
                        <a href="<?php echo e(route('locale', 'us')); ?>">
                            <img src="<?php echo e(url('/img/language/us.png')); ?>" alt="">
                        </a>
                    <?php else: ?>
                        <a href="<?php echo e(route('locale', 'ru')); ?>">
                            <img src="<?php echo e(url('/img/language/ru.png')); ?>" alt="">
                        </a>
                    <?php endif; ?>
                </div>
            </div>
            <nav class="open-user-menu">
                <img src="<?php echo e(asset('img/avatar5.png')); ?>" alt="avatar">
                <span>
                    <?php echo e(Auth::user()->name); ?>

            </span>
            </nav>
        </div>
        <div class="dropdown-menu">
            <img src="<?php echo e(asset('img/avatar5.png')); ?>" alt="avatar">
            <div class="title">
                <div>
                    <?php echo app('translator')->get('pages.developer'); ?>
                </div>
            </div>
            <div class="dropdown-menu-nav">
                <div>
                    <button class="button user-settings"><?php echo app('translator')->get('pages.top_panel_settings'); ?></button>
                </div>
                <div>
                    <button data-go="exit" class="button"><?php echo app('translator')->get('pages.top_panel_log_off'); ?></button>
                </div>
            </div>
        </div>
    </section>
</header>
<main>
    <section class="sidebar no-active">
        <div class="user-panel">
            <div class="avatar-user-panel"></div>
            <span>
                <?php echo app('translator')->get('pages.developer'); ?>
            </span>
        </div>
        <ul class="sidebar-menu">
            <li class="header"><?php echo app('translator')->get('pages.menu'); ?></li>
            <?php echo $__env->make("developer.menu", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </ul>
    </section>
    <section class="content">
        <div class="container">
            <?php echo $__env->yieldContent("h3"); ?>
            <div>
                <?php echo $__env->yieldContent("main"); ?>
            </div>
        </div>
        <footer>
            Copyright © 2021 <a href="https://vitovtov.top" target="_blank">vitovtov.top</a>
        </footer>
    </section>
</main>

















































</body>
</html>
<?php /**PATH D:\OSPanel\domains\botV2\resources\views/developer/template.blade.php ENDPATH**/ ?>