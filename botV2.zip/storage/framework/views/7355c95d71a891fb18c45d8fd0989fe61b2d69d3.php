<?php $__env->startComponent('menu.menu-item', [
               'name' => 'developer_admin_panel',
               'icon' => 'icon-user-3',
               'menu' => 'admin',
               'url' => '/admin']); ?>
<?php if (isset($__componentOriginal6d24f37cb7e6d98d46a220195dece646fa7436ce)): ?>
<?php $component = $__componentOriginal6d24f37cb7e6d98d46a220195dece646fa7436ce; ?>
<?php unset($__componentOriginal6d24f37cb7e6d98d46a220195dece646fa7436ce); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>






<?php $__env->startComponent('menu.menu-item', [
    'name' => 'request',
    'icon' => 'icon-code-2',
    'menu' => 'request',
    'url' => '/developer/request']); ?>
<?php if (isset($__componentOriginal6d24f37cb7e6d98d46a220195dece646fa7436ce)): ?>
<?php $component = $__componentOriginal6d24f37cb7e6d98d46a220195dece646fa7436ce; ?>
<?php unset($__componentOriginal6d24f37cb7e6d98d46a220195dece646fa7436ce); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->startComponent('menu.menu-item', [
    'name' => 'send_request',
    'icon' => 'icon-rocket',
    'menu' => 'send_request',
    'url' => '/developer/request/send']); ?>
<?php if (isset($__componentOriginal6d24f37cb7e6d98d46a220195dece646fa7436ce)): ?>
<?php $component = $__componentOriginal6d24f37cb7e6d98d46a220195dece646fa7436ce; ?>
<?php unset($__componentOriginal6d24f37cb7e6d98d46a220195dece646fa7436ce); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->startComponent('menu.menu-item', [
    'name' => 'developer_answers',
    'icon' => 'icon-help-1',
    'menu' => 'answers',
    'url' => '/developer/answers']); ?>
<?php if (isset($__componentOriginal6d24f37cb7e6d98d46a220195dece646fa7436ce)): ?>
<?php $component = $__componentOriginal6d24f37cb7e6d98d46a220195dece646fa7436ce; ?>
<?php unset($__componentOriginal6d24f37cb7e6d98d46a220195dece646fa7436ce); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->startComponent('menu.menu-rolled', [
    'nameItem' => 'payment',
    'icon' => 'icon-money-2',
    'name' => 'developer_pay',
    'items' => [[
            'name' => 'developer_qiwi',
            'menu' => 'payqiwi',
            'url' => '/developer/payment/qiwi'
        ],[
           'name' => 'developer_yandex_noney',
           'menu' => 'payyandex',
           'url' => '/developer/payment/yandex'
        ],[
           'name' => 'developer_webmoney',
           'menu' => 'paywebmoney',
           'url' => '/developer/payment/webmoney'
        ],[
           'name' => 'developer_paypal',
           'menu' => 'paypaypal',
           'url' => '/developer/payment/paypal'
        ]
    ]]); ?>
<?php if (isset($__componentOriginal629642e31854f2f3c320339cf9ca8b7a9b63fe21)): ?>
<?php $component = $__componentOriginal629642e31854f2f3c320339cf9ca8b7a9b63fe21; ?>
<?php unset($__componentOriginal629642e31854f2f3c320339cf9ca8b7a9b63fe21); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->startComponent('menu.menu-item', [
    'name' => 'developer_permissions',
    'icon' => 'icon-key-4',
    'menu' => 'permissions',
    'url' => '/developer/permissions']); ?>
<?php if (isset($__componentOriginal6d24f37cb7e6d98d46a220195dece646fa7436ce)): ?>
<?php $component = $__componentOriginal6d24f37cb7e6d98d46a220195dece646fa7436ce; ?>
<?php unset($__componentOriginal6d24f37cb7e6d98d46a220195dece646fa7436ce); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->startComponent('menu.menu-rolled', [
    'nameItem' => 'settings',
    'icon' => 'icon-cog-alt',
    'name' => 'developer_settings',
    'items' => [[
            'name' => 'developer_settings_main',
            'menu' => 'settingsmain',
            'url' => '/developer/settings/main'
        ],[
           'name' => 'developer_settings_pages',
           'menu' => 'settingspages',
           'url' => '/developer/settings/pages'
        ],[
           'name' => 'developer_settings_buttons',
           'menu' => 'settingsbuttons',
           'url' => '/developer/settings/buttons'
        ]
    ]]); ?>
<?php if (isset($__componentOriginal629642e31854f2f3c320339cf9ca8b7a9b63fe21)): ?>
<?php $component = $__componentOriginal629642e31854f2f3c320339cf9ca8b7a9b63fe21; ?>
<?php unset($__componentOriginal629642e31854f2f3c320339cf9ca8b7a9b63fe21); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH D:\OSPanel\domains\bot_laravel_8\resources\views/developer/menu.blade.php ENDPATH**/ ?>