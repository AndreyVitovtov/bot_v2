<?php $__env->startSection("title"); ?>
    <?php echo app('translator')->get('pages.edit_text_menu'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("h3"); ?>
    <h3><?php echo app('translator')->get('pages.edit_text_menu'); ?></h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("main"); ?>
    <form action="<?php echo e(route('lang-menu-edit-save')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="key" value="<?php echo e($key); ?>">
        <div>
            <label for="text"><?php echo app('translator')->get('pages.text'); ?> Ru</label>
            <input type="text" name="textRu" value="<?php echo e($textRu); ?>" id="text">
        </div>
        <div>
            <label for="text"><?php echo app('translator')->get('pages.text'); ?> Us</label>
            <input type="text" name="textUs" value="<?php echo e($textUs); ?>" id="text">
        </div>
        <div>
            <label for="key"><?php echo app('translator')->get('pages.key'); ?></label>
            <input type="text" name="newKey" value="<?php echo e($key); ?>" id="key">
        </div>
        <br>
        <div>
            <input type="submit" value="<?php echo app('translator')->get('pages.save'); ?>" class="button">
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("developer.template", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\botV2\resources\views/developer/lang/menu-edit.blade.php ENDPATH**/ ?>