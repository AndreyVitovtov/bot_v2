<?php $__env->startSection("title"); ?>
    <?php echo app('translator')->get('pages.analize'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("h3"); ?>
    <h3><?php echo app('translator')->get('pages.analize'); ?></h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("main"); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/mailing.css')); ?>">
    <script src="<?php echo e(asset('https://www.gstatic.com/charts/loader.js')); ?>"></script>
    <script src="<?php echo e(asset('js/charts/Chart.js')); ?>"></script>
    <script>
        let data = <?php echo json_encode($data); ?>;
        chart.options.colors = ['#3c8dbc', '#FF0000'];
        chart.options.title = '<?php echo app('translator')->get('pages.mailing_messages_sent'); ?>'+data.all
        chart.data = [
            ['', '<?php echo app('translator')->get('pages.mailing_successfully'); ?>', '<?php echo app('translator')->get('pages.mailing_not_successful'); ?>'],
            ['<?php echo app('translator')->get('pages.mailing_count_messages'); ?>', data.true, data.false]
        ];
        chart.drawBar('chart_div');
    </script>

    <div class="chart_analize_mailing_log">
        <div id="chart_div"></div>
    </div>
    <br>
    <hr>
    <br>
    <div>
        <form action="/admin/mailing/mark-inactive-users" method="POST">
            <?php echo csrf_field(); ?>
            <input type="submit" value="<?php echo app('translator')->get('pages.analize_mark_inactive_users'); ?>" class="button">
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("admin.template", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\botV2\resources\views/admin/mailing/mailing-analize.blade.php ENDPATH**/ ?>