<?php $__env->startSection("title"); ?>
    <?php echo app('translator')->get('pages.send_request'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("h3"); ?>
    <h3><?php echo app('translator')->get('pages.send_request'); ?></h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("main"); ?>
    <style>
        textarea {
            width: 100%;
            height: 100px;
            resize: none;
            border: solid 1px #ddd;
        }

        iframe {
            height: 390px;
        }
    </style>

    <form action="<?php echo e(route('get-response')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <label><?php echo app('translator')->get('pages.headers'); ?></label>
        <br>
        <div>
            <input type="checkbox" name="messenger" value="viber" id="viber"
                <?php if((isset($messenger) && $messenger == 'viber')): ?>
                    checked
                <?php endif; ?>
            >
            <label for="viber" class="cursor-pointer">Viber</label>
        </div>
        <br>
        <label><?php echo app('translator')->get('pages.options'); ?></label>
        <br>
        <div>
            <input type="radio" name="options" value="none" class="options" id="none" checked>
            <label for="none" class="cursor-pointer">None</label>

            <input type="radio" name="options" value="migrate" class="options" id="migrate">
            <label for="migrate" class="cursor-pointer">Migrate</label>

            <input type="radio" name="options" value="seed" class="options" id="seed">
            <label for="seed" class="cursor-pointer">Seed</label>

            <input type="radio" name="options" value="webhook" class="options" id="webhook">
            <label for="webhook" class="cursor-pointer">Webhook</label>
        </div>
        <div class="hidden" id="options_webhook">
            <br>
            <label>Webhook</label>
            <br>
            <input type="radio" name="type" value="telegram" class="type" id="type_telegram" checked>
            <label for="type_telegram" class="cursor-pointer">Telegram</label>
            <input type="radio" name="type" value="viber" class="type" id="type_viber">
            <label for="type_viber" class="cursor-pointer">Viber</label>
            <br>
            <br>
            <label for="token">Token</label>
            <input type="text" name="token" id="token">
        </div>
        <br>
        <label><?php echo app('translator')->get('pages.method'); ?></label>
        <br>
        <div>
            <input type="radio" name="method" value="post" id="post"
            <?php if((isset($method) && $method == 'post') || !isset($method)): ?>
                checked
            <?php endif; ?>
            class="method">
            <label for="post" class="cursor-pointer">POST</label>
            &nbsp;&nbsp;&nbsp;
            <input type="radio" name="method" value="get" id="get"
            <?php if(isset($method) && $method == 'get'): ?>
               checked
            <?php endif; ?>
            class="method">
            <label for="get" class="cursor-pointer">GET</label>
        </div>
        <br>
        <div>
            <label for="url">Url</label>
            <input type="text" name="url" value="<?php echo e(isset($url) ? $url : route('bot-request-handler')); ?>" id="url">
            <input type="hidden" name="old_url" value="<?php echo e(isset($url) ? $url : route('bot-request-handler')); ?>" id="old_url">
        </div>
        <br>
        <div>
            <label for="request"><?php echo app('translator')->get('pages.request'); ?></label>
            <textarea name="data" id="request"><?php echo e($data); ?></textarea>
        </div>
        <br>
        <button class="button"><?php echo app('translator')->get('pages.send'); ?></button>
    </form>
    <?php if(isset($response) && $response != null): ?>
        <br>
        <br>
        <label><?php echo app('translator')->get('pages.response'); ?></label>
        <br>
        <?php if(substr($response, 0, 1) == '{'): ?>
            <div id="json-renderer" class="json-body"></div>
            <script>
                let json = '<?php echo $response; ?>';
                $('#json-renderer').jsonBrowse(JSON.parse(json), {withQuotes: true});
            </script>
        <?php else: ?>
            <iframe src="<?php echo e(url('html/response.html')); ?>" width="100%"></iframe>
        <?php endif; ?>
    <?php endif; ?>

    <script>
        $('body').on('change', '.options', function() {
            let url = $('#old_url').val();
            $('#url').val(url);
            let radio = $(this).val();
            if(radio === 'webhook') {
                $('#url').prop('disabled', true);
                $('#get').prop('disabled', true);
                $('#post').prop('disabled', true);
                $('textarea').prop('disabled', true);
                $('#options_webhook').toggle();
                $('#token').focus();
                $('#token').val('<?php echo e($telegramToken); ?>');
            }
            else {
                if($('div #options_webhook').is((':visible'))) {
                    $('#options_webhook').toggle();
                    $('#url').prop('disabled', false);
                    $('#get').prop('disabled', false);
                    $('#post').prop('disabled', false);
                    $('textarea').prop('disabled', false);
                }
                if(radio === 'none') {
                    $('#post').prop('checked', true);
                    $('textarea').prop('disabled', false);
                    return;
                }
                let old_url = $('#old_url').val();
                $('#old_url').val(old_url);
                $('#get').prop('checked', true);
                $('textarea').prop('disabled', true);
                $('#url').val('<?php echo e(url('')); ?>/'+radio);
            }
        });

        $('body').on('change', '.type', function() {
            let type = $(this).val();
            if(type == 'telegram') {
                $('#token').val('<?php echo e($telegramToken); ?>');
            }
            else if(type == 'viber') {
                $('#token').val('<?php echo e($viberToken); ?>');
            }
            $('#token').focus();
        });

        let method = $('input[name=method]:checked').val();

        if(method == 'get') {
            $('textarea').prop('disabled', true);
        }
        $('body').on('change', '.method', function() {
            method = $('input[name=method]:checked').val();

            if(method == 'get') {
                $('textarea').prop('disabled', true);
            }
            else {
                $('textarea').prop('disabled', false);
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("developer.template", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\botV2\resources\views/developer/request/send.blade.php ENDPATH**/ ?>