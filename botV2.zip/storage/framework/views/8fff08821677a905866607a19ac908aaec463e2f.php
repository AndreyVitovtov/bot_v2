<script src="<?php echo e(asset('https://www.gstatic.com/charts/loader.js')); ?>"></script>
<script src="<?php echo e(asset('js/admin-panel/charts/Chart.js')); ?>"></script>

<div class="<?php echo e($class ?? ''); ?>" id="<?php echo e($id ?? ''); ?>">

</div>

<script>
    chart.options.title = "<?php echo e($title); ?>";
    chart.data = '<?php echo e(json_encode($data)); ?>';
    chart.drawBar(<?php echo e($id); ?>);
</script>
<?php /**PATH D:\OSPanel\domains\botV2\resources\views/charts/bar.blade.php ENDPATH**/ ?>