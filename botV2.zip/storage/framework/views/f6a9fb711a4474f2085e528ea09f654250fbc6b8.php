<?php $__env->startSection("title"); ?>
    <?php echo app('translator')->get('pages.answers'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("h3"); ?>
    <h3><?php echo app('translator')->get('pages.answers'); ?></h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("main"); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/answers.css')); ?>">

    <div class="answers">
        <div>
            <table border="1">
                <tr class="head">
                    <td>
                        №
                    </td>
                    <td>
                        <?php echo app('translator')->get('pages.answer'); ?>
                    </td>
                    <td>
                        <?php echo app('translator')->get('pages.question'); ?>
                    </td>
                    <td>
                        <?php echo app('translator')->get('pages.method'); ?>
                    </td>
                    <td>
                        <?php echo app('translator')->get('pages.actions'); ?>
                    </td>
                </tr>
                <?php $__currentLoopData = $answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td>
                            <?php echo e($answer['question']); ?>

                        </td>
                        <td>
                            <?php echo e($answer['answer']); ?>

                        </td>
                        <td>
                            <?php echo e($answer['method']); ?>

                        </td>
                        <td class="actions">
                            <div>
                                <form action="<?php echo route('edit-answer'); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="id" value="<?php echo e($answer['id']); ?>">
                                    <button>
                                        <i class='icon-pen'></i>
                                    </button>
                                </form>

                                <form action="<?php echo route('delete-answer'); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="id" value="<?php echo e($answer['id']); ?>">
                                    <button>
                                        <i class='icon-trash-empty'></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
        <br>
        <br>
        <form action="<?php echo route('add-answer'); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div>
                <label for="question"><?php echo app('translator')->get('pages.answer'); ?></label>
                <input type="text" name="question" id="question">
            </div>
            <div>
                <label for="answer"><?php echo app('translator')->get('pages.question'); ?></label>
                <input type="text" name="answer" id="answer">
            </div>
            <div>
                <label for="method"><?php echo app('translator')->get('pages.method'); ?></label>
                <input type="text" name="method" id="method">
            </div>
            <br>
            <div>
                <input type="submit" value="<?php echo app('translator')->get('pages.add'); ?>" class="button">
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("developer.template", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\botV2\resources\views/developer/answers/answers.blade.php ENDPATH**/ ?>