

<?php $__env->startSection("title"); ?>
    WebMoney
<?php $__env->stopSection(); ?>

<?php $__env->startSection("h3"); ?>
    <h3>WebMoney</h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("main"); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/pay.css')); ?>">

    <div class="payment">
        <div>
            <form action="<?php echo route('webmoney-save'); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div>
                    <label for="wallet">Кошелек:</label>
                    <input type="text" name="wallet" id="wallet" value="<?php echo e(isset($wallet) ? $wallet : ""); ?>">
                </div>
                <div>
                    <label for="secret">Secret Key:</label>
                    <input type="text" name="secret" id="secret" value="<?php echo e(isset($secret) ? $secret : ""); ?>">
                </div>
                <br>
                <div>
                    <input type="submit" value="Сохранить" class="button">
                </div>
            </form>
        </div>
        <br>
        <pre>Активировать кошелек для приема средств:</pre>
        <pre><a href="https://merchant.webmoney.ru/conf/SimpleWizardConstructor.asp">https://merchant.webmoney.ru/conf/SimpleWizardConstructor.asp</a></pre>
        <br>
        <pre>Перейти на <a href="https://merchant.webmoney.ru/conf/purses.asp">https://merchant.webmoney.ru/conf/purses.asp</a></pre>
        <pre>Выбрать нужный кошелек, нажать "настроить"</pre>
        <pre>В открывшемся окне заполнить форму</pre>
        <br>
        <pre>Отметить checkbox: "Высылать на Result URL, если обеспечивается секретность"</pre>
        <br>
        <pre>Result URL: <?php echo e(url('/payment/webmoney/handler')); ?></pre>
        <pre>Success URL: <?php echo e(url('/payment/webmoney/success')); ?></pre>
        <pre>Fail URL: <?php echo e(url('/payment/webmoney/fail')); ?></pre>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("developer.template", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\botV2\resources\views/developer/payment/webmoney-index.blade.php ENDPATH**/ ?>