<?php $__env->startSection("title"); ?>
    <?php echo app('translator')->get('pages.settings_main'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("h3"); ?>
    <h3><?php echo app('translator')->get('pages.settings_main'); ?></h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("main"); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/settings.css')); ?>">

    <form action="/admin/settings/main/save" method="POST">
        <?php echo csrf_field(); ?>
        <div class="settings">
            <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div>

                    <label for="<?php echo e($field['prefix']); ?>"><?php echo app('translator')->get('settings_main.'.$field['prefix']); ?></label>
                    <input type="<?php echo e($field['type']); ?>" name="input[<?php echo e($field['id']); ?>]" value="<?php echo e($field['value']); ?>">
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="block_buttons">
                <input type="submit" value="<?php echo app('translator')->get('pages.save'); ?>" class="button">
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("admin.template", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\botV2\resources\views/admin/settings/settings-main.blade.php ENDPATH**/ ?>