<?php $__env->startSection("title"); ?>
    <?php echo app('translator')->get('pages.settings_main'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("h3"); ?>
    <h3><?php echo app('translator')->get('pages.settings_main'); ?></h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("main"); ?>
    <table>
        <tr>
            <td>№</td>
            <td><?php echo app('translator')->get('pages.field_name'); ?></td>
            <td><?php echo app('translator')->get('pages.prefix'); ?></td>
            <td><?php echo app('translator')->get('pages.value'); ?></td>
            <td><?php echo app('translator')->get('pages.type'); ?></td>
            <td><?php echo app('translator')->get('pages.actions'); ?></td>
        </tr>
        <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($field['name']); ?></td>
                <td><?php echo e(mb_strtoupper($field['prefix'])); ?></td>
                <td><?php echo e(mb_strimwidth($field['value'], 0, 100, "...")); ?></td>
                <td><?php echo e($field['type']); ?></td>
                <td class="actions">
                    <div>
                        <form action="/developer/settings/main/edit" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" value="<?php echo e($field['id']); ?>">
                            <button>
                                <i class='icon-pen'></i>
                            </button>
                        </form>
                        <form action="/developer/settings/main/delete" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" value="<?php echo e($field['id']); ?>">
                            <button>
                                <i class='icon-trash-empty'></i>
                            </button>
                        </form>
                    </div>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <br>
    <form action="/developer/settings/main/add" method="POST">
        <?php echo csrf_field(); ?>
        <div>
            <label for="name"><?php echo app('translator')->get('pages.field_name'); ?>:</label>
            <input type="text" name="name" id="name">
        </div>
        <div>
            <label for="name_us"><?php echo app('translator')->get('pages.field_name_us'); ?>:</label>
            <input type="text" name="name_us" id="name_us">
        </div>
        <div>
            <label for="prexix"><?php echo app('translator')->get('pages.prefix'); ?></label>
            <input type="text" name="prefix" id="prefix">
        </div>
        <div>
            <label for="value"><?php echo app('translator')->get('pages.value'); ?></label>
            <input type="text" name="value" id="value">
        </div>
        <div>
            <label for="type"><?php echo app('translator')->get('pages.type'); ?></label>
            <select name="type" id="type">
                <option value="number">Number</option>
                <option value="text">Text</option>
                <option value="date">Date</option>
            </select>
        </div>
        <br>
        <div>
            <input type="submit" value="<?php echo app('translator')->get('pages.add'); ?>" class="button">
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("developer.template", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\botV2\resources\views/developer/settings/settings-main.blade.php ENDPATH**/ ?>