<?php $__env->startSection("title"); ?>
    <?php echo app('translator')->get('pages.answers'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("h3"); ?>
    <h3><?php echo app('translator')->get('pages.answers'); ?></h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("main"); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/answers.css')); ?>">

    <div class="answers">
        <div>
            <table border="1">
                <tr class="head">
                    <td>
                        №
                    </td>
                    <td>
                        <?php echo app('translator')->get('pages.answers_question'); ?>
                    </td>
                    <td>
                        <?php echo app('translator')->get('pages.answers_answer'); ?>
                    </td>
                    <td>
                        <?php echo app('translator')->get('pages.actions'); ?>
                    </td>
                </tr>
                <?php $__currentLoopData = $answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td>
                            <?php echo e($answer['question']); ?>

                        </td>
                        <td>
                             <?php echo e($answer['answer']); ?>

                        </td>
                        <td class="actions">
                            <div>
                                <form action="/admin/answers/edit" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="id" value="<?php echo e($answer['id']); ?>">
                                    <button>
                                        <i class='icon-pen'></i>
                                    </button>
                                </form>

                                <form action="/admin/answers/delete" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="id" value="<?php echo e($answer['id']); ?>">
                                    <button>
                                        <i class='icon-trash-empty'></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("admin.template", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\botV2\resources\views/admin/answers/answers-list.blade.php ENDPATH**/ ?>