

<?php $__env->startSection("title"); ?>
    <?php echo app('translator')->get('pages.users'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("h3"); ?>
    <h3><?php echo app('translator')->get('pages.users'); ?></h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("main"); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/users.css')); ?>">

    <form action="/admin/users/search" method="GET">
        <?php echo csrf_field(); ?>
        <div class="users">
            <div>
                <label for="search"><?php echo app('translator')->get('pages.users_search_label'); ?></label>
                <input type="text" name="str" id="search" value="<?php if(!empty($str)): ?><?php echo e($str); ?><?php endif; ?>" autofocus>
            </div>
            <div class="block_buttons">
                <input type="submit" value="<?php echo app('translator')->get('pages.users_search_button'); ?>" class="button">
            </div>
        </div>
    </form>
    <div class="overflow-X-auto">
    <table>
        <tr>
            <td>№</td>
            <td>ID Chat</td>
            <td><?php echo app('translator')->get('pages.users_username'); ?></td>
            <td><?php echo app('translator')->get('pages.users_date'); ?></td>
            <td><?php echo app('translator')->get('pages.users_profile'); ?></td>
        </tr>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($user['chat']); ?></td>
                <td><?php echo e($user['username']); ?></td>
                <td><?php echo e($user['date']); ?> <?php echo e($user['time']); ?></td>
                <td class="actions">
                    <div>
                        <a href="/admin/users/profile/<?php echo e($user['id']); ?>">
                            <button><i class='icon-user-8'></i></button>
                        </a>
                    </div>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php if(empty($user)): ?>
            <tr>
                <td colspan="5" style="text-align: center; font-size: 18px; padding: 20px;">
                    <?php echo app('translator')->get('pages.users_no'); ?>
                </td>
            </tr>
        <?php endif; ?>
    </table>
    </div>
    <?php echo e($users->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("admin.template", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\bot_laravel_8\resources\views/admin/users/users.blade.php ENDPATH**/ ?>