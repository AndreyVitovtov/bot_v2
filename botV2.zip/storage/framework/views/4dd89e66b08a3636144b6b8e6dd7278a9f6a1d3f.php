<?php $__env->startSection("title"); ?>
    <?php echo app('translator')->get('pages.settings_pages'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("h3"); ?>
    <h3><?php echo app('translator')->get('pages.settings_pages'); ?></h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("main"); ?>
    <table>
        <tr>
            <td>№</td>
            <td><?php echo app('translator')->get('pages.name'); ?></td>
            <td><?php echo app('translator')->get('pages.text'); ?></td>
            <td><?php echo app('translator')->get('pages.menu'); ?></td>
            <td><?php echo app('translator')->get('pages.actions'); ?></td>
        </tr>
        <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($field['name']); ?></td>
                <td><?php echo e(base64_decode($field['text'])); ?></td>
                <td><?php echo e($field['menu']); ?></td>
                <td class="actions">
                    <div>
                        <form action="/developer/settings/buttons/edit" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" value="<?php echo e($field['id']); ?>">
                            <button>
                                <i class='icon-pen'></i>
                            </button>
                        </form>
                        <form action="/developer/settings/buttons/delete" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" value="<?php echo e($field['id']); ?>">
                            <button>
                                <i class='icon-trash-empty'></i>
                            </button>
                        </form>
                    </div>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <br>
    <form action="/developer/settings/buttons/add" method="POST">
        <?php echo csrf_field(); ?>
        <div>
            <label for="name"><?php echo app('translator')->get('pages.name'); ?></label>
            <input type="text" name="name" id="name">
        </div>
        <div>
            <label for="text"><?php echo app('translator')->get('pages.text'); ?></label>
            <input type="text" name="text" id="text">
        </div>
        <div>
            <label for="name"><?php echo app('translator')->get('pages.menu'); ?></label>
            <input type="text" name="menu" id="menu">
        </div>
        <div>
            <label for="menu_us"><?php echo app('translator')->get('pages.menu_us'); ?></label>
            <input type="text" name="menu_us" id="menu_us">
        </div>
        <br>
        <div>
            <button class="button"><?php echo app('translator')->get('pages.add'); ?></button>
        </div>
        </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("developer.template", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\botV2\resources\views/developer/settings/settings-buttons.blade.php ENDPATH**/ ?>