<?php
    return [
        'authorization' => 'Авторизация',
        'login' => 'Логин',
        'password' => 'Пароль',
        'sign_in' => 'Войти',
    ];
