<?php
return [
    'title' => 'Панель управления',
    'panel_p' => 'П',
    'left_panel_panel' => 'Панель',
    'left_panel_administrator' => 'Администратор',
    'left_panel_menu' => 'Меню',
    'top_panel_administrator' => 'Администратор',
    'top_panel_settings' => 'Настройки',
    'top_panel_log_off' => 'Выйти'
];
