<?php
    return [
        'authorization' => 'Authorization',
        'login' => 'Login',
        'password' => 'Password',
        'sign_in' => 'Sign in',
    ];
