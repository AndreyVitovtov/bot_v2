<?php
return [
    'title' => 'Control Panel',
    'panel_p' => 'P',
    'left_panel_panel' => 'Panel',
    'left_panel_administrator' => 'Administrator',
    'left_panel_menu' => 'Menu',
    'top_panel_administrator' => 'Administrator',
    'top_panel_settings' => 'Settings',
    'top_panel_log_off' => 'Log off'
];
