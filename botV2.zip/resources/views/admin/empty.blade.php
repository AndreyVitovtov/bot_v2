@extends("admin.template")

@section("title")
    @lang('pages.')
@endsection

@section("h3")
    <h3>@lang('pages.')</h3>
@endsection

@section("main")
    <div>

    </div>
@endsection
